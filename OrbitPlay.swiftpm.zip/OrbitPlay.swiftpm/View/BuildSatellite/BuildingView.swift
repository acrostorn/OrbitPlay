//
//  BuildingView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/11.
//

import SwiftUI
import SceneKit

struct BuildingView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var userComponents: UserComponents
    @Environment(\.dismiss) private var dismiss
    @State private var showComponentDetail = false
    @State private var showNavi = false
    @State private var isCircle = true
    @State private var isEnd = false
    
    var body: some View {
        ZStack {
            VStack {
                ZStack() {
                    SatelliteScene()
                    
                    VStack {
                        HStack {
                            let flag = userComponents.bodyMaterial.name != "Wire Blanket" && userComponents.solarPanel.name != "Wire Panel"
                            VStack(alignment: .leading) {
                                Button() {
                                    if flag {
                                        dismiss()
                                        if appState.appSequence == .welcomeToSatellite {
                                            appState.appSequence = .naviToOrbit
                                        }
                                    }
                                } label: {
                                    Image(systemName: "chevron.left").foregroundStyle(flag ? Color.black : Color.grayBlack)
                                        .padding()
                                        .background(
                                            Circle().fill(flag ? .white : .gray.opacity(0.5))
                                        )
                                }
                                .padding(.bottom)
                                
                                Spacer()
                            }
                            
                            Spacer()
                            
                            
                            ComponentInfoPad(showComponentDetail: $showComponentDetail)
                                .offset(x: showComponentDetail ? 0 : 300)
                                .animation(.easeIn, value: showComponentDetail)
                        }
                        .padding(.vertical)
                        
                        SelectorView(showComponentDetail: $showComponentDetail)
                    }
                    .padding(25)
                    
                    VStack {
                        HStack {
                            PropatyView()
                        }
                        Spacer()
                    }
                    .padding(50)
                }
            }
            .navigationBarBackButtonHidden()
            .navigationBarHidden(true)
            
            if showNavi {
                Rectangle().fill(.black.opacity(0.75)).frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                SatelliteIntroSheet(showNavi: $showNavi)
                    .transition(.move(edge: .top))
            }
            
        }
        .ignoresSafeArea()
        .onAppear {
            if appState.appSequence == .naviToSatellite {
                appState.appSequence = .welcomeToSatellite
            }
        }
    }
    
    @ViewBuilder
    func MissionCard() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.gray.opacity(0.5))
                .frame(width: 260)
        }
        .padding([.trailing, .vertical])
    }
    
    @State var testflag = false
    @ViewBuilder
    private func theButton() -> some View {
        Button() {
            testflag.toggle()
        } label: {
            ZStack {
                Image(systemName: "globe.americas").foregroundStyle(testflag ? .black : .white)
                Image(systemName: "line.diagonal").foregroundStyle(testflag ? .green : .gray)
            }
            .font(.largeTitle)
            .padding(5)
            .background(
                Circle()
                    .fill(testflag ? Color.white : Color.gray.opacity(0.3))
            )
        }
    }
}
