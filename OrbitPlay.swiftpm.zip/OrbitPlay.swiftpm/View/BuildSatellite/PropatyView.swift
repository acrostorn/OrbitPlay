//
//  PropatyView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/20.
//

import SwiftUI

struct PropatyView: View {
    @EnvironmentObject private var userComponents: UserComponents
    private let blueGradient: Gradient = Gradient(colors: [Color.blue, Color.cyan, Color.teal, Color.blue])
    
    @State private var completeFlag = false
    
    var body: some View {
        HStack {
            HStack {
                ComponentPreview(component: userComponents.bodyMaterial, color: UIColor(Color.clear)).frame(width: 35, height: 35)
                    .padding(.trailing, 5)
                VStack(alignment: .leading) {
                    Text("Body")
                        .bold()
                    Text(userComponents.bodyMaterial.name == "Wire Blanket" ? "not selected" : userComponents.bodyMaterial.name)
                        .font(.caption)
                }
                .foregroundStyle(userComponents.bodyMaterial.name == "Wire Blanket" ? .gray : .white)
            }
            .padding(.trailing)
            
            HStack {
                ComponentPreview(component: userComponents.solarPanel, color: UIColor(Color.clear)).frame(width: 35, height: 35)
                    .padding(.trailing, 5)
                VStack(alignment: .leading) {
                    Text("Solar Panel")
                        .bold()
                    Text(userComponents.solarPanel.name == "Wire Panel" ? "not selected" : userComponents.solarPanel.name)
                        .font(.caption)
                }
                .foregroundStyle(userComponents.solarPanel.name == "Wire Panel" ? .gray : .white)
            }
        }
        .padding()
        .background(
            ZStack {
                if  completeFlag {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(
                            LinearGradient(
                                gradient: blueGradient,
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .transition(.opacity)
                        .padding()
                }
                
                RoundedRectangle(cornerRadius: 5)
                    .fill(.thinMaterial)
                    .environment(\.colorScheme, .dark)
            }
        )
        .onChange(of: userComponents.values) {
            if userComponents.bodyMaterial.name != "Wire Blanket" && userComponents.solarPanel.name != "Wire Panel" {
                withAnimation {
                    completeFlag = true
                }
            }
        }
        .onAppear {
            if userComponents.bodyMaterial.name != "Wire Blanket" && userComponents.solarPanel.name != "Wire Panel" {
                withAnimation {
                    completeFlag = true
                }
            }
        }
    }
}

