import SwiftUI

struct ComponentInfoPad: View {
    @EnvironmentObject private var userComponents: UserComponents
    @Binding var showComponentDetail: Bool
    @State private var showDetails = false
    @State private var scrollFlash = false
    @State private var showedComponents: [String] = []
    
    var body: some View {
        VStack {
            Text(userComponents.selectedComponent.name)
                .font(.title3)
                .bold()
            
            ComponentPreview(component: userComponents.selectedComponent, color: UIColor.white)
                .frame(width: 165, height: 165)
            
            ScrollViewReader { proxy in
                ScrollView {
                    Text(userComponents.selectedComponent.description)
                        .fixedSize(horizontal: false, vertical: true)
                        .allowsTightening(true)    
                        .multilineTextAlignment(.leading)     
                        .minimumScaleFactor(0.8) 
                        .id("top")
                }
                .frame(maxWidth: .infinity)
                .padding(3)
                .background(Rectangle().fill(Color.gray.opacity(0.1)))
                .frame(maxHeight: showDetails ? .infinity : 150)
                .overlay(LinearGradient(gradient: Gradient(colors: [.white.opacity(showDetails ? 0 : 0.3), .white.opacity(showDetails ? 0 : 1)]), startPoint: .top, endPoint: .bottom))
                .overlay(VStack {
                    Spacer()
                    Button(showDetails ? "" : "show detail ▼") {
                        withAnimation {
                            showDetails.toggle()
                            showedComponents.append(userComponents.selectedComponent.name)
                        }
                    }
                    .foregroundStyle(Color.blue)
                    .padding(.bottom, 6)
                })
                .padding(.bottom, 10)
                .onChange(of: userComponents.selectedComponent) {
                    if showedComponents.contains(userComponents.selectedComponent.name) {
                        showDetails = true
                    } else {
                        showDetails = false 
                    }                  
                    withAnimation {
                        proxy.scrollTo("top", anchor: .top)
                    }
                }
                .scrollIndicatorsFlash(trigger: scrollFlash)
            } 
                
                
            HStack {
                Spacer()
                
                Button("Cancel") {
                    showComponentDetail = false
                }
                .foregroundStyle(Color.grayBlack)
                .bold()
                .padding(.vertical, 5)
                .padding(.horizontal)
                .background(RoundedRectangle(cornerRadius: 5).fill(Color.gray.opacity(0.5)))
                
                Spacer()
                
                Button("Select") {
                    if userComponents.selectedComponent.type == .bodyMaterial {
                        userComponents.bodyMaterial = userComponents.selectedComponent
                    } else {
                        userComponents.solarPanel = userComponents.selectedComponent
                    }
                    showComponentDetail.toggle()
                }
                .foregroundStyle(.white)
                .bold()
                .padding(.vertical, 5)
                .padding(.horizontal)
                .background(RoundedRectangle(cornerRadius: 5).fill(Color.blue))
                
                Spacer()
            }
            .padding(.bottom, 5)
        }
        .foregroundStyle(Color.black)
        .padding(10)
        .frame(width: 250)
        .background(
            RoundedRectangle(cornerRadius: 15).fill(Color.white)
        )
        .onAppear {
            scrollFlash.toggle()
        }
        .onChange(of: showDetails) {
            if showDetails {
                scrollFlash.toggle()
            }
        }
    }
}
