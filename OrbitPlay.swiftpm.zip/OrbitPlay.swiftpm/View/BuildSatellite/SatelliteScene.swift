//
//  SatelliteScene.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/20.
//

import SwiftUI
import SceneKit

struct SatelliteScene: View {
    @EnvironmentObject var userComponents: UserComponents
    @State private var isDropTargeted = false
    @State private var scene = SCNScene()
    @State private var satelliteNode: SCNNode?
    
    var body: some View {
        SceneView(
            scene: scene,
            options: [.allowsCameraControl, .autoenablesDefaultLighting]
        )
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .border(.blue, width: isDropTargeted ? 0 : .zero)
        .dropDestination(for: SatelliteComponent.self) { droppedComponents, _ in
            addComponent(droppedComponents)
            return true
        } isTargeted: {
            isDropTargeted = $0
        }
        .onAppear {
            setupScene()
        }
        .onChange(of: userComponents.values) {
            updateSatelliteNode()
        }
    }
    
    private func setupScene() {
        scene.background.contents = UIColor.black.withAlphaComponent(0.94)
        updateSatelliteNode()
        
        let floor = SCNFloor()
        let floorMaterial = SCNMaterial()
        floorMaterial.diffuse.contents = UIColor(Color.white)
        
        floor.materials = [floorMaterial]
        floor.reflectivity = 0.15
        let floorNode = SCNNode(geometry: floor)
        floorNode.position = SCNVector3(x: 0, y: -0.6, z: 0)
        scene.rootNode.addChildNode(floorNode)
        
        //camera
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0, y: 1.5, z: 6)
        cameraNode.look(at: SCNVector3(0,-0.5,0))
        cameraNode.pivot = SCNMatrix4MakeTranslation(0,0,0)
        scene.rootNode.addChildNode(cameraNode)
        
        //spotLight
        let spotLight = SCNLight()
        spotLight.type = .spot
        spotLight.spotInnerAngle = 170 
        spotLight.spotOuterAngle = 179 
        spotLight.intensity = 500
        let spotLightNode = SCNNode()
        spotLightNode.light = spotLight
        spotLightNode.position = SCNVector3(x: 0, y: 35, z: 0)
        scene.rootNode.addChildNode(spotLightNode)
        spotLightNode.look(at:SCNVector3(0,0,0))
        
        moveCamera()
    }
    
    private func updateSatelliteNode() {
        satelliteNode?.removeFromParentNode()
        
        let newSatelliteNode = createSatelliteNode()
        scene.rootNode.addChildNode(newSatelliteNode)
        
        satelliteNode = newSatelliteNode
    }
    
    private func createSatelliteNode() -> SCNNode {
        let parentNode = SCNNode()
        
        //body
        let bodyNode = getModel(userComponents.bodyMaterial)
        bodyNode.position = SCNVector3(x:0, y:0, z:0)
        parentNode.addChildNode(bodyNode)
        
        //solarPanel
        let panelNodeL = getModel(userComponents.solarPanel)
        let panelNodeR = getModel(userComponents.solarPanel)
        panelNodeR.eulerAngles = SCNVector3(0, Float.pi, 0)
        panelNodeR.position = SCNVector3(-0.5, 0, 0)
        panelNodeL.position = SCNVector3(0.5, 0, 0)
        parentNode.addChildNode(panelNodeL)
        parentNode.addChildNode(panelNodeR)
        
        return parentNode
    }
    
    private func moveCamera() {
        guard let cameraNode = scene.rootNode.childNodes.first(where: { $0.camera != nil}) else { return }
        
        let lookAtConstraint = SCNLookAtConstraint(target: createLookAtTarget())
        lookAtConstraint.isGimbalLockEnabled = true
        
        cameraNode.constraints = [lookAtConstraint]
        
        let moveAction = SCNAction.move(to: SCNVector3(1.3,3,4), duration: 1)
        moveAction.timingMode = .easeInEaseOut
        
        cameraNode.runAction(moveAction)
    }
    
    private func createLookAtTarget() -> SCNNode {
        let targetNode = SCNNode()
        targetNode.position = SCNVector3(0,-0.5,0)
        scene.rootNode.addChildNode(targetNode)
        return targetNode
    }
    
    func addComponent(_ components: [SatelliteComponent]) {
        for component in components {
            switch component.type {
            case .bodyMaterial:
                userComponents.bodyMaterial = component
            case .solarPanel:
                userComponents.solarPanel = component
            case .camera:
                userComponents.camera = component
            case .sensor:
                userComponents.sensor = component
            case .coolingSystem:
                userComponents.coolingSystem = component
            case .antenna:
                userComponents.antenna = component
            }
        }
    }
}
