//
//  SelectorView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/20.
//

import SwiftUI

struct SelectorView: View {
    @EnvironmentObject var userComponents: UserComponents
    @State private var pickerComponents: String = "Body"
    @State private var selectedType: ComponentType = .bodyMaterial
    private let items: [String] = ["Body", "Solar Panel", /*"Camera", "Sensor", "CoolingSystem" ,"Antenna"*/]
    private let instructions = ["The Body forms the satellite’s core, housing systems such as communication, sensors, radiators, Earth observation cameras, etc.",
     "Solar Panels power your satellite by converting sunlight into electricity, charging the battery. Your choice impacts energy and charging efficiency."
    ]
    
    @Binding var showComponentDetail: Bool
    @State private var scrollFlash = false
    
    var body: some View {
        HStack {
            ScrollViewReader { proxy in
                ScrollView {
                    Text(selectedType == .bodyMaterial ? "Body" : "Solar Panel")
                        .foregroundStyle(Color.grayBlack)
                        .font(.title2)
                        .bold()
                        .padding(.bottom, 5)
                        .id("top")
                    Text(selectedType == .bodyMaterial ? instructions[0] : instructions[1])
                        .foregroundStyle(.white)
                        .fixedSize(horizontal: false, vertical: true)
                        .allowsTightening(true)    
                        .multilineTextAlignment(.leading)     
                        .minimumScaleFactor(0.8) 
                }
                .padding()
                .frame(width: 220)
                .background(RoundedRectangle(cornerRadius: 15).fill(Color.lightBlack))
                .onChange(of: pickerComponents) {
                    scrollFlash.toggle()
                    withAnimation {
                        proxy.scrollTo("top", anchor: .top)
                    }
                }
                .scrollIndicatorsFlash(trigger: scrollFlash)
            }
            
            VStack { 
                    VStack(alignment: .leading) {
                        Picker("select", selection: $pickerComponents) {
                            ForEach(items, id: \.self) { item in
                                Text(item).tag(item)
                            }
                        }
                        .onChange(of: pickerComponents) {
                            switch pickerComponents {
                            case "Body":
                                selectedType = .bodyMaterial
                            case "Solar Panel":
                                selectedType = .solarPanel
                            case "Sensor":
                                selectedType = .sensor
                            case "CoolingSystem":
                                selectedType = .coolingSystem
                            default :
                                print("'error")
                            }
                        }
                        .pickerStyle(.segmented)
                        .environment(\.colorScheme, .dark)
                        .padding(.bottom)
                        
                        ScrollView(.horizontal) {
                            HStack {
                                ForEach(userComponents.allComponents.filter({$0.type == selectedType}), id: \.self) { component in
                                    ComponentPreview(component: component, color: UIColor(Color.lightBlack))
                                        .frame(width: 120, height: 120)
                                        .clipShape(RoundedRectangle(cornerRadius: 15))
                                        .onTapGesture {
                                            userComponents.selectedComponent = component
                                            showComponentDetail = true
                                            
                                        }
                                        .draggable(component) {
                                            Image(systemName: "wrench.and.screwdriver")
                                                .foregroundStyle(.green)
                                                .font(.system(size: 50))
                                                .clipShape(RoundedRectangle(cornerRadius: 15))
                                                .bold()
                                        }
                                        .padding(.trailing, 30)
                                }
                                .padding(.leading, 30)
                            }
                        }
                    }
                }
                .padding(.leading)
        }
        .padding()
        .frame(height: 250)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 15).fill(Color.middleBlack)
        )
    }
}
