//
//  DesignOrbitView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/12.
//

import SwiftUI
import SceneKit

struct DesignOrbitView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var userParams: UserParams
    @Environment(\.dismiss) private var dismiss
    @State private var showNavi = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                ZStack(alignment: .trailing) {
                    Color(uiColor: UIColor.black)
                    
                    HStack {
                        VStack(alignment: .leading) {
                            Button() {
                                dismiss()
                                if appState.appSequence == .welcomeToOrbit {
                                    appState.appSequence = .goForLaunch
                                }
                            } label: {
                                Image(systemName: "chevron.left").foregroundStyle(Color.black)
                                    .padding()
                                    .background(
                                        Circle().fill(Color.white)
                                    )
                            }
                            .padding(.bottom)
                            .padding(.top, 25)
                            
                            DesigningManual()
                        }
                        
                        VStack {
                            OrbitSceneView()
                            
                            DesigningPad(params: userParams)
                        }
                        .padding(.leading, 25)
                    }
                    .navigationBarBackButtonHidden()
                    .onAppear {
                        if appState.appSequence == .naviToOrbit {
                            appState.appSequence = .welcomeToOrbit
                        }
                    }
                    .padding(25)
                }
                .ignoresSafeArea()
            }
        }
    }
}
