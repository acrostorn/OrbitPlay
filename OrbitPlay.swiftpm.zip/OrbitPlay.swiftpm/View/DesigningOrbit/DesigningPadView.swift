//
//  DesigningPadView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/12.
//

import SwiftUI

struct DesigningPad: View {
    @EnvironmentObject var userParams: UserParams
    @State private var localValues: [Float]
    
    init(params: UserParams) {
        var tmpArray: [Float] = []
        for value in params.values {
            tmpArray.append(value.value)
        }
        _localValues = State(initialValue: tmpArray) 
    }
    
    var body: some View {
        VStack {
            ForEach(userParams.values.indices, id: \.self) { index in
                let name = userParams.values[index].name
                let range = userParams.values[index].range
                let unit = userParams.values[index].unit
                let binding = Binding<Float>(
                    get: { localValues[index] },
                    set: { newValue in
                        localValues[index] = newValue
                        switch name {
                        case "Semi-Major Axis": userParams.a = newValue
                        case "Eccentricity": userParams.e = newValue
                        case "Inclination": userParams.i = newValue
                        case "Longitude of the Ascending Node": userParams.Ω = newValue
                        case "Argument of Perigee": userParams.ω = newValue
                        case "True Anomaly": userParams.ν = newValue
                        default: break
                        }
                    }
                )
                
                if ["Semi-Major Axis", "Inclination", "Longitude of the Ascending Node"].contains(name) {
                    HStack {
                        Text(name)
                            .lineLimit(3)
                            .foregroundStyle(.white)
                        
                        Button {
                            userParams.scrollCount += 1
                            userParams.infoItem = name
                        } label: {
                            Image(systemName: "info.circle")
                                .foregroundStyle(.gray)
                                .padding(5)
                        }
                        
                        Spacer()
                        
                        Text("\(String(floor(localValues[index]))) \(unit)")
                            .foregroundStyle(.white)
                    }
                    .font(.headline)
                    
                    
                    Slider(value: binding, in: range)
                        .padding(.bottom, name == "Longitude of the Ascending Node" ? 0 : 10)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 15).fill(Color.gray).opacity(0.5)
        )
    }
}
