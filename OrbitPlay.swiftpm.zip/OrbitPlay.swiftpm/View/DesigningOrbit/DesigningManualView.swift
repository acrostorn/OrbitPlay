//
//  DesigningManual.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/12.
//

import SwiftUI

struct DesigningManual: View {
    @EnvironmentObject private var userParams: UserParams
    
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading) {
                    Text("How Orbits Are Designed")
                        .foregroundStyle(.black)
                        .font(.system(size: 23))
                        .fontWeight(.heavy)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.bottom, 15)
                    
                    Image("OrbitalElements")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .padding(.vertical, 5)
                        .padding(.bottom, 5)
                        .padding(.horizontal, 40)
                    
                    HStack {
                        Spacer()
                        Text("(Image credit: Brandir, CC BY-SA 3.0)")
                            .font(.footnote)
                            .foregroundStyle(.gray)
                            .padding(.bottom, 15)
                        Spacer()
                    }
                    
                    firstCaption()
                        .padding(.bottom)
                    
                    Text("▶︎ Semi-Major Axis")
                        .font(.headline)
                        .bold()
                        .id("Semi-Major Axis")
                    
                    AutoReverseVideoView(videoName: "radiusMov", videoExtension: "mov")
                        .frame(height: 147)
                    
                    Text("The semi-major axis determines the size of the orbit by defining the distance between the satellite and the center of the Earth. In the case of a circular orbit, this value is equivalent to the orbital radius. A larger semi-major axis results in a higher orbit and a longer orbital period.")
                        .font(.subheadline)
                        .padding(.bottom, 15)
                    
                    
                    Text("▶︎ Inclination")
                        .font(.headline)
                        .bold()
                        .id("Inclination")
                    
                    AutoReverseVideoView(videoName: "inclinationMov", videoExtension: "mov")
                        .frame(height: 198)
                    
                    Text("Inclination represents the tilt of the orbit relative to Earth’s equator. It is measured in degrees from 0° (equatorial orbit) to 180°. A low inclination keeps the satellite near the equator, while a high inclination allows it to pass over more of the Earth’s surface.")
                        .font(.subheadline)
                    Text("For simplification, the range is limited to 0°–90°.")
                        .foregroundStyle(.gray)
                        .font(.footnote)
                        .padding(.bottom)
                    
                    Text("▶︎ Longitude of Ascending Node")
                        .font(.headline)
                        .bold()
                        .id("Longitude of the Ascending Node")
                    
                    AutoReverseVideoView(videoName: "ascendingMov", videoExtension: "mov")
                        .frame(height: 202)
                    
                    Text("The longitude of the ascending node (RAAN) defines the orientation of the orbit in space. It is the angle measured from a fixed reference direction (typically the vernal equinox) to the point where the satellite crosses the equatorial plane from south to north. This parameter determines where the orbit intersects the Earth’s equator.")
                        .font(.subheadline)
                    Text("For simplification, the vernal equinox is assumed to be the 0° longitude direction, and the range is limited to 0°–90°.")
                        .foregroundStyle(.gray)
                        .font(.footnote)
                        .padding(.bottom)
                }
                .foregroundStyle(.black)
            }
            .frame(width: 280)
            .frame(maxHeight: .infinity)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 15).fill(Color.white)
            )
            .onChange(of: userParams.scrollCount) {
                withAnimation {
                    proxy.scrollTo(userParams.infoItem, anchor: .top)
                }
                print(userParams.infoItem)
            }
        }
    }
    
    @ViewBuilder
    private func firstCaption() -> some View {
        Text("To define an orbit, six parameters known as the ").font(.subheadline) +
        Text("orbital elements ").font(.subheadline).bold() +
        Text("are used. In the case of a circular orbit, only three are necessary: ").font(.subheadline) +
        Text("semi-major axis").font(.subheadline).bold() +
        Text(", ").font(.subheadline) +
        Text("inclination").font(.subheadline).bold() +
        Text(", and ").font(.subheadline) +
        Text("longitude of ascending node").font(.subheadline).bold() +
        Text(". These determine the orbit’s size, tilt, and orientation in space.").font(.subheadline)
    }
}
