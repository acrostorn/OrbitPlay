//
//  OrbitScene.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/12.
//

import SwiftUI
import SceneKit

struct OrbitSceneView: View {
    @EnvironmentObject var userParams: UserParams
    @State var scene = SCNScene()
    @State private var ellipseNode: SCNNode?
    @State private var textNode: SCNNode?
    
    var body: some View {
        SceneView(
            scene: scene
        )
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            setupScene()
        }
        .onChange(of: userParams.values) {
            updateEllipseNode()
        }
    }
    
    func setupScene() {
        scene.background.contents = UIColor.black
        
        //earth
        let sphere = SCNSphere(radius: 1)
        sphere.segmentCount = 20
        let sphereMaterial = SCNMaterial()
        sphereMaterial.fillMode = .lines
        sphere.materials = [sphereMaterial]
        let sphereNode = SCNNode(geometry: sphere)
        scene.rootNode.addChildNode(sphereNode)
        
        let qq = SCNSphere(radius: 0.99)
        qq.segmentCount = 24
        let qqm = SCNMaterial()
        qqm.diffuse.contents = UIColor.gray
        qqm.transparency = 0.7
        qq.materials = [qqm]
        let qqn = SCNNode(geometry: qq)
        scene.rootNode.addChildNode(qqn)
        
        updateEllipseNode()
        
        //camera
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 2, y: 2, z: 3)
        cameraNode.look(at: SCNVector3(0, 0, 0))
        
        //light
        let light = SCNLight()
        light.type = .omni
        let lightNode = SCNNode()
        lightNode.light = light
        lightNode.position = SCNVector3(x: -5, y: 5, z: 7)
                
        scene.rootNode.addChildNode(cameraNode)
        scene.rootNode.addChildNode(lightNode)
        
        moveCamera()
    }
    
    func updateEllipseNode() {
        ellipseNode?.removeFromParentNode()
        
        let newEllipseNode = createEllipseNode()
        scene.rootNode.addChildNode(newEllipseNode)
        
        ellipseNode = newEllipseNode
        
        let a = userParams.a / 6400
        let Ω = userParams.Ω / 180 * .pi
        
        textNode?.removeFromParentNode()
        let textGeometry = SCNText(string: "Initial Position", extrusionDepth: 0.03)
        let textMaterial = SCNMaterial()
        textMaterial.diffuse.contents = UIColor.white
        textMaterial.emission.contents = UIColor.white
        textGeometry.materials = [textMaterial]
        let newTextNode = SCNNode(geometry: textGeometry)
        newTextNode.position = SCNVector3(a * sin(Ω), 0.25, a * cos(Ω))
        newTextNode.scale = SCNVector3(0.02, 0.02, 0.02)
        
        scene.rootNode.addChildNode(newTextNode)
        
        textNode = newTextNode
    }
    
    
    func createEllipseNode() -> SCNNode {
        let a: Float = userParams.a / 6400
        let b: Float = calculateShortRadius(a: a, e: userParams.e)
        let i: Float = userParams.i
        let Ω: Float = userParams.Ω
        let segments = 100
        var vertices = [SCNVector3]()
        
        let width: Float = a
        let height: Float = b
        
        for j in 0...segments {
            let angle = Float(j) * (2 * Float.pi / Float(segments))
            let x = width * cos(angle)
            let z = height * sin(angle)
            vertices.append(SCNVector3(x, 0, z))
        }
        
        let vertexSource = SCNGeometrySource(vertices: vertices)
        var indices = [Int32]()
        for j in 0..<segments {
            indices.append(Int32(j))
            indices.append(Int32(j + 1))
        }
        
        //close
        indices.append(Int32(segments))
        indices.append(0)
        
        let element = SCNGeometryElement(indices: indices, primitiveType: .line)
        let geometry = SCNGeometry(sources: [vertexSource], elements: [element])
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.systemBlue
        material.emission.contents = UIColor.systemBlue
        geometry.materials = [material]
        
        let tmpNode = SCNNode(geometry: geometry)
        
        let startAngle: Float = 0
        let startX = width * cos(startAngle) 
        let startZ = height * sin(startAngle)   
        
        let startParentNode = SCNNode()
        
        let arrowMaterial = SCNMaterial()
        arrowMaterial.diffuse.contents = UIColor.cyan
        arrowMaterial.emission.contents = UIColor.cyan
        
        let point = SCNSphere(radius: 0.05)
        point.materials = [arrowMaterial]
        let pointNode = SCNNode(geometry: point)
        pointNode.position = SCNVector3(startX, 0, startZ)
        startParentNode.addChildNode(pointNode)
        
        let cylinder = SCNCylinder(radius: 0.02, height: 0.2)
        cylinder.materials = [arrowMaterial]
        let cylinderNode = SCNNode(geometry: cylinder)
        cylinderNode.eulerAngles = SCNVector3(Float.pi/2,0,0)
        cylinderNode.position = SCNVector3(startX, 0, startZ - 0.1)
        startParentNode.addChildNode(cylinderNode)
        
        let cone = SCNCone(topRadius: 0, bottomRadius: 0.05, height: 0.1)
        cone.materials = [arrowMaterial]
        let coneNode = SCNNode(geometry: cone)
        coneNode.eulerAngles = SCNVector3(-1 * Float.pi/2,0,0)
        coneNode.position = SCNVector3(startX, 0, startZ - 0.25)
        startParentNode.addChildNode(coneNode)
        
        let eulerXAngle = i * Float.pi / 180
        let eulerYAngle = (-.pi / 2) + (Ω * .pi / 180)
        
        tmpNode.addChildNode(startParentNode)
        tmpNode.eulerAngles = SCNVector3(x: eulerXAngle, y: eulerYAngle, z: 0)
        
        return tmpNode
    }
    
     private func moveCamera() {
         
        guard let cameraNode = scene.rootNode.childNodes.first(where: { $0.camera != nil}) else { return }
         
        let lookAtConstraint = SCNLookAtConstraint(target: createLookAtTarget())
        lookAtConstraint.isGimbalLockEnabled = true
        
        cameraNode.constraints = [lookAtConstraint]
        
        let moveAction = SCNAction.move(to: SCNVector3(0,3,11), duration: 2)
        moveAction.timingMode = .easeInEaseOut
         
        cameraNode.runAction(moveAction)
    }
    
    private func createLookAtTarget() -> SCNNode {
        let targetNode = SCNNode()
        targetNode.position = SCNVector3(0,0,0)
        scene.rootNode.addChildNode(targetNode)
        return targetNode
    }
    
    func calculateShortRadius(a: Float, e: Float) -> Float {
        let b: Float
        b = a * sqrt(1 - powf(e, 2))
        print(b)
        return b
    }
}
