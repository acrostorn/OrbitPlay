import SwiftUI
import Charts

struct ResultView: View {
    @EnvironmentObject private var appState: AppState
    let positionData: [MapPlotData]
    let sensorData: [SensorData]
    let batteryData: [ChartData]
    @State private var showReport = false
    @State var isExpandedTemperature = false
    @State var isExpandedTrajectory = false
    @State var isExpandedBattery = false
    
    var body: some View {
        VStack(alignment: .leading) {
            ScrollView(.vertical) {
                Text(showReport ? "Mission Report" : "🏆 Mission Succeed!! 🏆")
                    .font(.title)
                    .fontWeight(.heavy)
                    .padding(.vertical, 35)
                    .frame(maxWidth: .infinity)
                
                if !showReport {
                    Text("Great job on your mission! Your report is complete and provides valuable insights into your success. Please check it out.")
                        .bold()
                        .padding(.bottom, 35)
                        .transition(.opacity)
                } else {
                    VStack(spacing: 0) {
                        Divider()
                            .padding(.bottom, 35)
                        
                        TemperatureSection(sensorData: sensorData, isExpanded: $isExpandedTemperature)
                        
                        Divider()
                            .padding(.vertical, 35)
                        
                        TrajectorySection(data: positionData, isExpanded: $isExpandedTrajectory)
                        
                        Divider()
                            .padding(.vertical, 35)
                        
                        BatterySection(data: batteryData, isExpanded: $isExpandedBattery)
                        
                        
                        Divider()
                            .padding(.vertical, 35)
                    }
                    .transition(.opacity)
                }
                    
                
                Button {
                    if !showReport {
                        withAnimation(.easeInOut(duration: 0.6)) {
                            showReport.toggle()
                        }
                    } else {
                        appState.appSequence = .finishAR
                    }
                } label: {
                    Text(!showReport ? "Show Report" : "OK")
                        .foregroundStyle(.white)
                        .bold()
                        .padding()
                        .padding(.horizontal)
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(.black)
                        )
                }
                .padding(.bottom, 35)
            }
        }
        .foregroundStyle(.black)
        .padding()
        .frame(width: showReport ? 500 : 400)
        .frame(maxHeight: showReport ? .infinity : 337)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.white)
        )
    }
}
