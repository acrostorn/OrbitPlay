import SwiftUI
import Charts

struct TrajectorySection: View {
    let data: [MapPlotData]
    @Binding var isExpanded: Bool
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Trajectory")
                .font(.title2)
                .fontWeight(.heavy)
            
            Image("world.topo.200406.3x5400x2700")
                .resizable()
                .aspectRatio(contentMode: . fit)
                .overlay(trajectoryChart())
                .padding(.bottom)
            
            Text("This graph displays the satellite’s orbital trajectory on an Earth map, depicted solely as the orbital path curve. The visualization provides clear insights into the satellite’s overall orbit and movement.")
                .font(.subheadline)
                .padding(.bottom, 5)
            
            Button("What Happens When Satellites Are Operated Long-Term?") {
                withAnimation {
                    isExpanded.toggle()
                }
            }
            .foregroundStyle(.blue)
            .font(.caption)
            
            if isExpanded {
                
                Text("When satellites are operated over extended periods, their orbits gradually change due to external influences such as atmospheric drag and minor variations in gravitational forces. These effects, known as 'perturbations,' accumulate over time and make it increasingly difficult to predict a satellite’s position accurately in the distant future. As a result, long-term satellite operations require regular monitoring and periodic adjustments to maintain the intended orbit.\n \n(Source: JAXA FAQ, fanfun.jaxa.jp/faq)")
                    .font(.subheadline)
                    .transition(.opacity)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 15)
                            .fill(.gray.opacity(0.25))
                    )
            }
        }
        .frame(maxWidth: .infinity)
    }
    
    @ViewBuilder
    private func trajectoryChart() -> some View {
        Chart(data) { point in
            LineMark(
                x: .value("Longitude", point.lon),
                y: .value("Latitude", point.lat)
            )
            .interpolationMethod(.catmullRom)
            .foregroundStyle(by: .value("Segment", point.segmentID))
        }
        .chartXScale(domain: -180...180)
        .chartYScale(domain: -90...90)
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .chartLegend(.hidden)
        .frame(height: 250)
        .environment(\.colorScheme, .light)
    }
}
