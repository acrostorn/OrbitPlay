import SwiftUI
import Charts

struct BatterySection: View {
    var data: [ChartData]
    @Binding var isExpanded: Bool
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Battery")
                .font(.title2)
                .fontWeight(.heavy)
            
            batteryChart()
                .padding(.bottom)
            
            Text("This graph shows how the battery level changes over time depending on the solar panels’ orientation. When the panels face the sun, the battery charges and the level rises; when they are not aligned with the sun, the battery discharges and the level drops.")
                .font(.subheadline)
                .padding(.bottom, 5)
            
            Button("How Do Space Solar Panels Differ from Ground-Based Ones?") {
                withAnimation {
                    isExpanded.toggle()
                }
            }
            .foregroundStyle(.blue)
            .font(.caption)
            
            if isExpanded {
                VStack {
                    Image("panel")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .padding(.bottom, 5)
                    
                    Text("(Image credit: NASA/JPL-Caltech/Lockheed Martin)")
                        .font(.footnote)
                        .foregroundStyle(.gray)
                        .padding(.bottom, 5)
                    
                    Text("Space solar panels are designed to withstand extreme conditions. They use single-crystal silicon or GaAs compounds that resist degradation better than the multi-crystalline or amorphous materials common on Earth. While ground panels can exceed 20% efficiency, space panels focus on durability to perform reliably under extreme temperatures, radiation, and vacuum.\n \n(Source: JAXA FAQ, fanfun.jaxa.jp/faq)")
                        .font(.subheadline)
                        .transition(.opacity)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 15)
                        .fill(.gray.opacity(0.25))
                )
            }
        }
        .frame(maxWidth: .infinity)
    }
    
    @ViewBuilder
    private func batteryChart() -> some View {
        let newData = Array(data.dropFirst(15))
        Chart(newData) { point in
            BarMark(
                x: .value("X", point.x - 15),
                y: .value("Y", point.y)
            )
        }
        .foregroundStyle(.green)
        .chartYScale(domain: 0...100)
        .chartYAxisLabel(position: .trailing, alignment: .center, spacing: 5) {
            Text("%")
                .fontWeight(.heavy)
        }
        .chartXAxis(.hidden)
        .frame(height: 250)
        .environment(\.colorScheme, .light)
        .padding(.bottom)
    }
}
