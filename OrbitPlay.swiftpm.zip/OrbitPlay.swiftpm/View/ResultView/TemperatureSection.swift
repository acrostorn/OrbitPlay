import SwiftUI
import Charts

struct TemperatureSection: View {
    @EnvironmentObject private var userComponents: UserComponents
    let sensorData: [SensorData]
    @Binding var isExpanded: Bool
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Temperature")
                .font(.title2)
                .fontWeight(.heavy)
            
            Chart(sensorData) { point in
                LineMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("external", point.externalValue)
                )
                .interpolationMethod(.catmullRom)
                .foregroundStyle(by: .value("Series", "External"))
                
                PointMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("external", point.externalValue)
                )
                .foregroundStyle(.orange)
                
                LineMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("internal", point.internalValue)
                )
                .interpolationMethod(.catmullRom)
                .foregroundStyle(by: .value("Series", "Internal"))
                
                PointMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("internal", point.internalValue)
                )
                .foregroundStyle(.blue)
            }
            .chartForegroundStyleScale([
                "External": .orange,
                "Internal": .blue
            ])
            .chartYScale(domain: -170...170)
            .chartYAxis {
                AxisMarks(values: .stride(by: 50)) { value in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel {
                        if let intValue = value.as(Int.self) {
                            Text("\(intValue) °C")
                                .bold()
                                .font(.caption)
                        }
                    }
                }
            }
            .chartXAxis(.hidden)
            .frame(height: 250)
            .environment(\.colorScheme, .light)
            .padding(.bottom)
            
            Text("When the satellite is exposed to direct sunlight, its external temperature can rise close to 100°C due to intense solar radiation. However, even when illuminated, the sensor may not always receive direct sunlight, limiting the temperature increase. As the satellite moves into Earth's shadow, it no longer receives sunlight and rapidly cools down, sometimes dropping below -100°C.")
                .font(.subheadline)
                .padding(.bottom, 5)
            
            Button("Why Are the Internal Temperature Variations Small?") {
                withAnimation {
                    isExpanded.toggle()
                }
            }
            .foregroundStyle(.blue)
            .font(.caption)
            .padding(.bottom, 5)
            
            if isExpanded {
                VStack {
                    Image("material")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .padding(.bottom, 5)
                    
                    Text("(Image credit: Steve Jurvetson, CC BY 2.0)")
                        .font(.footnote)
                        .foregroundStyle(.gray)
                        .padding(.bottom, 5)
                    
                    Text("As shown in the insulation material photo above, advanced insulation minimizes heat transfer from the harsh external environment. When combined with active temperature control and a design that evenly distributes heat, it ensures the satellite’s interior remains remarkably stable.")
                        .font(.subheadline)
                        .transition(.opacity)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 15)
                        .fill(.gray.opacity(0.25))
                )
            }
        }
        .frame(maxWidth: .infinity)
    }
}
