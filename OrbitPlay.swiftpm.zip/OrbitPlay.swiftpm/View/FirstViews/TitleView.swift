//
//  OpeningView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/09.
//
import SwiftUI
import SceneKit

struct TitleView: View {
    @EnvironmentObject private var appState: AppState
    @State var isStart = false
    @State private var launchingFlag = false
    @State private var isAnimating = false
    
    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                
                Text("Orbit Play")
                    .font(.system(size: 80, weight: .black, design: .default))
                    .foregroundStyle(.white)
                    .padding(.bottom, 30)
                
                Spacer()
                
                TitleEarthScene()
                    .frame(width: 300, height: 300)
                    .padding(.bottom)
                
                Spacer()
                
                NavigationLink("START") {
                    DashboardView()
                        .navigationBarBackButtonHidden(true)
                        .onAppear {
                            if appState.appSequence == .appStart {
                                appState.appSequence = .tapMe
                            }
                        }
                }
                .font(.largeTitle)
                .fontWeight(.heavy)
                .foregroundStyle(.white)
                .padding(.bottom, 30)
                
                Text("Riju Ishiwatari's Entry for the WWDC25 Swift Student Challenge")
                    .foregroundStyle(.white)
                    .font(.headline)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 15).fill(Color.middleBlack)
                    )
                    .padding(.horizontal, 30)
                    .padding(.bottom, 30)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(
                Color.darkBlack
            )
        }
        .ignoresSafeArea()
    }
    
    
    struct TitleEarthScene: UIViewRepresentable {
        func makeUIView(context: Context) -> SCNView {
            let scnView = SCNView()
            let scene = SCNScene()
            scnView.scene = scene
            scnView.autoenablesDefaultLighting = false
            //        scnView.allowsCameraControl = true
            scene.background.contents = UIColor(Color.darkBlack)
            
            //earth
            let earthNode = SCNNode(geometry: SCNSphere(radius: 1))
            earthNode.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "earth_texture_map_with_clouds___1k___by_colourness_dg3wwrg-pre")
            earthNode.position = SCNVector3(0,0,0)
            earthNode.eulerAngles = SCNVector3(0,-1 * Float.pi / 4 ,0)
            scene.rootNode.addChildNode(earthNode)
            
            //animation
            let rotation = SCNAction.rotateBy(x: 0, y: .pi * 4, z: 0, duration: 300)
            let repeatRotation = SCNAction.repeatForever(rotation)
            earthNode.runAction(repeatRotation)
            
            //sunlight
            let sunLight = SCNLight()
            sunLight.type = .directional
            sunLight.castsShadow = true
            let sunNode = SCNNode()
            sunNode.light = sunLight
            sunNode.look(at: SCNVector3(0,0,0))
            sunNode.position = SCNVector3(-1, 8, -6)
            scene.rootNode.addChildNode(sunNode)
            
            //camera
            let cameraNode = SCNNode()
            cameraNode.camera = SCNCamera()
            cameraNode.position = SCNVector3(x: -1.5, y: 0, z: 1.5)
            cameraNode.look(at: SCNVector3(0,0,0))
            scene.rootNode.addChildNode(cameraNode)
            
            return scnView
        }
        
        func updateUIView(_ uiView: SCNView, context: Context) {}
    }
}
