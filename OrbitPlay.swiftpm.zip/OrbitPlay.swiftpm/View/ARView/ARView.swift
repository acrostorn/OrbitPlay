//
//  ARView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/12/11.
//
import SwiftUI
import SceneKit

struct ARView: View {
    @State private var gradientPosition: CGFloat = 0.0
    @State var scale: Float = 0.5
    @State private var isShowAlertBack = false
    @Environment(\.dismiss) private var dismiss
    @State var coordinator = Coordinator()
    @EnvironmentObject var appState: AppState
    @State private var showNavi = false
    @State var count = 0
    @State var isMissionSucceeded = false
    @State private var showPostureScene = false
    @State private var isStartCamera = false
    @State var batteryData: [ChartData] = (1...15).map { ChartData(x: $0, y: 100) }
    @State var positionData: [MapPlotData] = []
    @State var postureData: [PostureData] = []
    @State var sensorData: [SensorData] = [] 
    
    @State var worldPosition = SCNVector3(0, 1, 0)
    @State var ω = SCNVector3(1,1,0)
    
    @State private var showStartButton = false
    @State private var showIndicator = false
    
    @State var eulerAngles = SCNVector3(0,0,0)
    
    var body: some View {
        ZStack(alignment: .bottom) {
            if showPostureScene {
                SatellitePostureScene(worldPosition: $worldPosition, postureData: $postureData, eulerAngles: $eulerAngles, ω: ω)
                
                CameraImageScene(isStartCamera: $isStartCamera)
            }
            
            ARViewContainer(coordinator: $coordinator, arSequence: $appState.arSequence, scale: $scale, batteryData: $batteryData, positionData: $positionData, postureData: $postureData, sensorData: $sensorData, isMissionSucceeded: $isMissionSucceeded, ω: $ω, worldPosition: $worldPosition, eulerAngles: $eulerAngles)
            
            if isMissionSucceeded {
                if let image = coordinator.getARImage() {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                }
                
                Rectangle()
                    .fill(.thinMaterial)
                    .environment(\.colorScheme, .dark)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .transition(.opacity)
            }
            
            if appState.arSequence == .contemplatingPlacement || appState.arSequence == .objectPlaced {
                Rectangle()
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.black, Color.black.opacity(0)]),
                            startPoint: .bottom,
                            endPoint: .top
                        )
                    )
                    .frame(maxWidth: .infinity)
                    .frame(height: 500)
            }
            
            ZStack(alignment: .bottom) {
                if appState.arSequence == .contemplatingPlacement {
                    VStack {
                        Spacer()
                        
                        Button {
                            showIndicator.toggle()
                            
                            DispatchQueue.main.async {
                                coordinator.triggerDeployScene()
                                showIndicator.toggle()
                            }
                            
                        } label: {
                            Text("Deploy")
                                .font(.title)
                                .shadow(color: .blue, radius: 3)
                                .bold()
                                .foregroundStyle(.white)
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 10).fill(Color.black).shadow(color: .blue, radius: 3)
                                )
                        }
                        .padding(60)
                    }
                }
                
                VStack {
                    if showStartButton {
                        HStack {
                            Text("×")
                            Text(String(format: "%.1f", scale))
                        }
                        .font(.title)
                        .bold()
                        .foregroundStyle(Color.white)
                        .padding()
                        CustomSlider(width: 500, scale: $scale)
                            .padding(.bottom, 30)
                    }
                    
                    if showStartButton {
                        HStack {
                            Button {
                                coordinator.reDeployScene()
                                showStartButton.toggle()
                            } label: {
                                Text("ReDeploy")
                                    .font(.title)
                                    .bold()
                                    .foregroundStyle(Color.black)
                                    .padding()
                                    .background(
                                        ZStack {         
                                            RoundedRectangle(cornerRadius: 10).fill(Color.gray.opacity(0.9))    
                                        }
                                    )
                            }
                            .padding(.trailing, 30)
                            
                            Button {
                                showStartButton.toggle()
                                showIndicator.toggle()
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                                    showIndicator.toggle()
                                    appState.arSequence = .missionStart
                                    isStartCamera.toggle()
                                }
                            } label: {
                                Text("Mission Start")
                                    .font(.title)
                                    .shadow(color: .blue, radius: 3)
                                    .bold()
                                    .foregroundStyle(.white)
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10).fill(Color.black)
                                            .shadow(color: .blue, radius: 3)
                                    )
                            }
                        }
                    }
                }
                .padding(60)
            }
            
            if showNavi {
                Rectangle().fill(.black.opacity(0.75)).frame(maxWidth: .infinity, maxHeight: .infinity)
                VStack {
                    Spacer()
                    SatelliteIntroSheet(showNavi: $showNavi)
                        .transition(.move(edge: .top))
                    Spacer()
                }
            }
            
            if showIndicator {
                VStack {
                    Spacer()
                    
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                        .environment(\.colorScheme, .light)
                        .scaleEffect(1)
                        .padding(40)
                        .background(
                            RoundedRectangle(cornerRadius: 5).fill(.ultraThinMaterial).environment(\.colorScheme, .light)
                        )
                    
                    Spacer()
                }
            }
            
            if isMissionSucceeded {
                VStack {
                    Spacer()
                    ResultView(positionData: positionData, sensorData: sensorData, batteryData: batteryData)
                        .padding(60)
                    Spacer()
                }
                .onChange(of: appState.appSequence) {
                    if appState.appSequence == .finishAR {
                        dismiss()
                    }
                }
                .transition(.move(edge: .top))
            }
        }
        .ignoresSafeArea()
        .alert("Do you really back to home ?", isPresented: $isShowAlertBack) {
            Button("Yes", role: .destructive) {
                dismiss()
            }
            Button("Cancel", role: .cancel) { }
        }
        .onChange(of: appState.arSequence) {
            if appState.arSequence == .showIntroSheet {
                showNavi.toggle()
            }
            if appState.arSequence == .contemplatingPlacement {
                showPostureScene = false
            } else if appState.arSequence == .objectPlaced {
                showPostureScene = true
                showStartButton = true
            } else if appState.arSequence == .missionStart {
                coordinator.startMission()
            } else if appState.arSequence == .missionSucceed {
                showPostureScene = false
            }
        }
        .onChange(of: showNavi) {
            if !showNavi && appState.arSequence == .showIntroSheet {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    appState.arSequence = .missionStart
                    isStartCamera.toggle()
                }
            }
        }
        .onChange(of: count) {
            if isMissionSucceeded {
                appState.arSequence = .missionSucceed
                print(positionData)
            }
        }
    }
}
