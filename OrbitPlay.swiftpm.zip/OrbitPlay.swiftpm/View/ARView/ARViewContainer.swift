//
//  ARViewContainer.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/12/11.
//

import SwiftUI
import ARKit
import SceneKit

struct ARViewContainer: UIViewRepresentable {
    @EnvironmentObject var userParams: UserParams
    @EnvironmentObject var userComponents: UserComponents
    @EnvironmentObject var imageHolder: ImageHolder
    @Binding var coordinator: Coordinator
    @Binding var arSequence: ARSequence
    @Binding var scale: Float
    @Binding var batteryData: [ChartData]
    @Binding var positionData: [MapPlotData]
    @Binding var postureData: [PostureData]
    @Binding var sensorData: [SensorData]
    @Binding var isMissionSucceeded: Bool
    @Binding var ω: SCNVector3
    @Binding var worldPosition: SCNVector3
    @Binding var eulerAngles: SCNVector3
    let arView = ARSCNView()
    @State private var counter: Float = 0
    @State private var timer: Timer?
    @State var θ: Float = 0
    @State var spaceLon: Float?
    
    func makeCoordinator() -> Coordinator {
        return coordinator
    }
    
    func makeUIView(context: Context) -> ARSCNView {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal 
        arView.session.run(configuration)
        arView.scene = SCNScene()   
        arView.delegate = context.coordinator
        
        let coachingOverlayView = ARCoachingOverlayView()
        coachingOverlayView.session = arView.session
        coachingOverlayView.delegate = context.coordinator
        coachingOverlayView.goal = .horizontalPlane
        coachingOverlayView.activatesAutomatically = true
        coachingOverlayView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        arView.addSubview(coachingOverlayView)
        coachingOverlayView.setActive(true, animated: true)
        
        context.coordinator.parent = self
        context.coordinator.setupFoucsNode(for: arView)
        
        setupImages()
        
        return arView
    }
    
    func updateUIView(_ uiView: ARSCNView, context: Context) {
        if isMissionSucceeded {
            if let image = ARFunctions.render(TimerDeviceView(progress: 1)),
               let data = image.pngData(),
               let png = UIImage(data: data) {
                coordinator.timerImage = png
            }
            coordinator.updateTimer()
            stopSession()
        }
        
        if arSequence == .objectPlaced || arSequence == .contemplatingPlacement {
            coordinator.updateScale(scale)
        } else if arSequence == .missionStart {
            
            if θ/360 < 0.9 {
                //sensor
                self.updateSensorData()
                
                //posture
                self.updatePosturDeviceData()
                
                self.updateBattery()
            }
            
            if θ/360 < 0.95 {                
                //position
                self.updatePositionData()
                
                //timer
                self.updateTimerData()
                
                //posture
                coordinator.postureImage = imageHolder.postureImage
                coordinator.updatePosture()
                
                //camera
                coordinator.cameraImage = imageHolder.cameraImage
                coordinator.updateCamera()
            }
        }
    } 
    
    private func updatePosturDeviceData() {
        if let image = ARFunctions.render(PostureDeviceView(data: postureData)),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.postureDeviceImage = png
        }
        
        coordinator.updatePostureDevice()
    }
    
    private func updateTimerData() {
        if let image = ARFunctions.render(TimerDeviceView(progress: θ/360)),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.timerImage = png
        }
        coordinator.updateTimer()
    }
    
    private func updateBattery() {
//        guard let spaceLon = spaceLon else { return }
        var chargeValue: Float = 0
        
        if worldPosition.z >= 0 {
            chargeValue = userComponents.solarPanel.cost
        }
        
        var yValue = batteryData.last!.y - Float.random(in: 2...5) + chargeValue
        if yValue >= 100 {
            yValue = 100
        }
        
        DispatchQueue.main.async {
            let newData = ChartData(x: batteryData.count + 1, y: yValue)
            batteryData.append(newData)
        }
        
        if let image = ARFunctions.render(ChartDeviceView(data: batteryData.suffix(15))),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.batteryImage = png
        }
        
        coordinator.updateBattery()
    }
    
    private func updatePositionData() {
        if let node = coordinator.satelliteNode.childNode(withName: "satellite", recursively: true) {
            DispatchQueue.main.async {
                let tmpPosition = SCNVector3(node.worldPosition.x, node.worldPosition.y, node.worldPosition.z)
                let vector = SCNVector3(tmpPosition.x-coordinator.pivotPosition.x, tmpPosition.y-coordinator.pivotPosition.y-0.085*scale, tmpPosition.z-coordinator.pivotPosition.z)
                worldPosition = vector
                let posture = node.worldOrientation
                self.eulerAngles = quaternionToEulerAngles(posture)
                func quaternionToEulerAngles(_ q: SCNVector4) -> SCNVector3 {
                    let sinr_cosp = 2 * (q.w * q.x + q.y * q.z)
                    let cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y)
                    let x = atan2(sinr_cosp, cosr_cosp)
                    
                    let sinp = 2 * (q.w * q.y - q.z * q.x)
                    let y: Float
                    if abs(sinp) >= 1 {
                        y = copysign(Float.pi / 2, sinp)
                    } else {
                        y = asin(sinp)
                    }
                    
                    let siny_cosp = 2 * (q.w * q.z + q.x * q.y)
                    let cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
                    let z = atan2(siny_cosp, cosy_cosp)
                    
                    return SCNVector3(x, y, z)
                }
                positionData.append(coordinator.getPosition(vector))
            }
            
            if let image = ARFunctions.render(mapDeviceView(data: positionData)),
               let data = image.pngData(),
               let png = UIImage(data: data) {
                coordinator.mapImage = png
                coordinator.updateMap()
            }
        }
    }
    
    private func updateSensorData() {
//        guard let spaceLon = spaceLon else { return }
        let hardGradient: Float = 50/0.03
        let mildGradient: Float = 25/0.02
        var externalValue: Float = 0
        var internalValue: Float = 0
        
        print(worldPosition.z / scale)
        
        DispatchQueue.main.async {
            if worldPosition.z / scale >= -0.01 {
                if worldPosition.z / scale < 0.03 {
                    externalValue = hardGradient * worldPosition.z / scale + 80
                } else {
                    externalValue = mildGradient * (worldPosition.z / scale - 0.03) + 90
                }
            } else {
                if worldPosition.z / scale > -0.03 {
                    externalValue = hardGradient * (worldPosition.z / scale + 0.01) - 80
                } else {
                    externalValue = mildGradient * (worldPosition.z / scale + 0.03) - 100
                }
            }
            
            internalValue = externalValue * userComponents.bodyMaterial.weight
            sensorData.append(SensorData(internalValue: internalValue, externalValue: externalValue))
        } 
        
        if let image = ARFunctions.render(SensorDeviceView(data: sensorData)),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.sensorImage = png
        }
        coordinator.updateSensor() 
    }
    
    private func setupImages() {
        if let image = ARFunctions.render(ChartDeviceView(data: batteryData)),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.batteryImage = png
        }
        
        if let image = ARFunctions.render(mapDeviceView(data: positionData)),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.mapImage = png
        }
        
        if let image = ARFunctions.render(SensorDeviceView(data: sensorData)),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.sensorImage = png
        }
        
        if let image = ARFunctions.render(TimerDeviceView(progress: 0)),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.timerImage = png
        }
        
        if let image = ARFunctions.render(LiveBadgeView()),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.badgeImage = png
        }
        
        if let image = ARFunctions.render(PostureDeviceView(data: [])),
           let data = image.pngData(),
           let png = UIImage(data: data) {
            coordinator.postureDeviceImage = png
        }
    }
    
    private func stopSession() {
        arView.session.pause()
    }
}
