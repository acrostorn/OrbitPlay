import SwiftUI
import SceneKit
import ARKit

class Coordinator: NSObject, ARSCNViewDelegate, ARCoachingOverlayViewDelegate {
    var parent: ARViewContainer?
    private var parentNode = SCNNode()
    private var focusNode = SCNNode()
    private var trackedRaycast: ARTrackedRaycast?
    weak var arView: ARSCNView?
    private var focusPosition: SCNVector3?
    var chartImage: UIImage?
    var postureImage: UIImage?
    var mapImage: UIImage?
    var sensorImage: UIImage?
    var timerImage: UIImage?
    var cameraImage: UIImage?
    var batteryImage: UIImage?
    fileprivate var postureCanvasNode = SCNNode()
    var satelliteNode = SCNNode()
    private var mapCanvasNode = SCNNode()
    private var sensorCanvasNode = SCNNode()
    private var cameraCanvasNode = SCNNode()
    private var batteryCanvasNode = SCNNode()
    private var earthNode = SCNNode()
    var pivotPosition = SCNVector3(0,0,0)
    var badgeImage: UIImage?
    var previousMapPlotData: MapPlotData? = nil
    var segmentCounter: Int = 0
    var postureDeviceImage: UIImage?
    fileprivate var postureDeviceCanvasNode = SCNNode()
    @State private var timer: Timer?
    private var TimerCanvasNode = SCNNode()
    private var orbitNode = SCNNode()
    
    func getARImage() -> UIImage? {
        guard let frame = parent!.arView.session.currentFrame else { return nil }
        let pixelBuffer = frame.capturedImage
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let context = CIContext()
        
        if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
            return UIImage(cgImage: cgImage)
        }
        return nil
    }
    
    func setPivotPosition() {
        self.pivotPosition = SCNVector3(parentNode.worldPosition.x, parentNode.worldPosition.y, parentNode.worldPosition.z)
    }
    
    private func updateAxisVector() {
        let orbitTransform = self.satelliteNode.presentation.worldTransform
        let length = sqrt(orbitTransform.m21 * orbitTransform.m21 +
                          orbitTransform.m22 * orbitTransform.m22 +
                          orbitTransform.m23 * orbitTransform.m23)
        
        let axisVector = SCNVector3(orbitTransform.m21 / length,
                                    orbitTransform.m22 / length,
                                    orbitTransform.m23 / length)
        
        parent!.ω = axisVector
        
        print(axisVector)
    }
    
    func getPosition(_ position: SCNVector3) -> MapPlotData {
        let x = position.x
        let y = position.y
        let z = position.z
        parent!.θ = earthNode.eulerAngles.y * (180 / .pi)
        let r = sqrt(x * x + y * y + z * z)
        
        let lat = asin(y / r) * 180 / .pi 
        let MG: Float = 4 * pow(10, 14)
        
        
        var tmpLon = atan(x/z) * 180 / .pi
        
        if z == 0 && x > 0 {
            tmpLon = 90
        } else if z == 0 && x < 0 {
            tmpLon = -90
        }
        
        if x > 0 && z < 0 {
            tmpLon = 180 + tmpLon
        } else if x < 0 && z < 0 {
            tmpLon = -1 * (180 - tmpLon)  
        }
        
        var lon = tmpLon - parent!.θ
        
        let radius = parent!.userParams.a * 1000
        let ω: Float = sqrt(MG/pow(radius, 3))
        let dayθ = (ω * 24 * 60 * 60) * 180 / .pi
        let ratio = parent!.θ/360
        let tmpSpaceLon = (ratio * dayθ).remainder(dividingBy: 360)
        
        if tmpSpaceLon >= 0 {
            parent!.spaceLon = tmpSpaceLon
        } else {
            parent!.spaceLon = 360 + tmpSpaceLon
        }
        
        if lon <= -180 {
            lon += 360
        }
        var currentSegmentID = segmentCounter
        if let prev = previousMapPlotData {
            let distance = sqrt(pow(lon - prev.lon, 2) + pow(lat - prev.lat, 2))
            if distance > 170 {
                segmentCounter += 1
                currentSegmentID = segmentCounter
            }
        }
        
        let newPoint = MapPlotData(lon: lon, lat: lat, segmentID: currentSegmentID)
        previousMapPlotData = newPoint
        return newPoint
    }
    
    func startMission() {
        rotateSatellite()
        rotateEarth()
        setPivotPosition()
        stopRaycastTimer()
        
        orbitNode.removeFromParentNode()
    }
    
    private func rotateSatellite() {
        let r = parent!.userParams.a * 1000
        let MG: Float = 4 * pow(10, 14)
        let ω: Float = sqrt(MG/pow(r, 3))
        let orbitTransform = self.satelliteNode.presentation.worldTransform
        let axisVector = SCNVector3(orbitTransform.m21, orbitTransform.m22, orbitTransform.m23) 
        let rotateAction = SCNAction.rotate(by: CGFloat(ω * 24 * 60 * 60), around : axisVector, duration: 24)
        
        satelliteNode.runAction(rotateAction)
    }
    
    
    private func rotateEarth() {
        let rotateAction = SCNAction.rotateBy(x: 0, y: 2 * .pi, z: 0, duration: 24)
        
        let completionAction = SCNAction.run { _ in
//            print("Earth rotation completed!")
            self.missionFinish()
        }
        
        let sequence = SCNAction.sequence([rotateAction, completionAction])
        earthNode.runAction(sequence)
    }
    
    private func missionFinish() {
        DispatchQueue.main.async {
            withAnimation {
                self.parent!.isMissionSucceeded = true
            }
            self.parent!.arSequence = .missionSucceed
        }
    }
    
    func updateTimer() {
        
        TimerCanvasNode.removeFromParentNode()
        
        let newNode = createTimerCanvas()
        parentNode.addChildNode(newNode)
        
        TimerCanvasNode = newNode
    }
    
    func createTimerCanvas() -> SCNNode {
        let canvas = SCNPlane(width: 1, height: 0.5)
        let material = SCNMaterial()
        
        if let image = timerImage {
            material.diffuse.contents = image
        } else {
            material.diffuse.contents = UIColor.gray
        }
        material.isDoubleSided = true
        material.transparencyMode = .dualLayer
        canvas.materials = [material]
        TimerCanvasNode = SCNNode(geometry: canvas)
        TimerCanvasNode.scale = SCNVector3(0.05,0.05,0.05)
        TimerCanvasNode.position = SCNVector3(-0.1, 0.1575, 0)
        
        return TimerCanvasNode
    }
    
    func updatePostureDevice() {
        postureDeviceCanvasNode.removeFromParentNode()
        
        let newNode = createPostureDeviceCanvasNode()
        parentNode.addChildNode(newNode)
        
        postureDeviceCanvasNode = newNode
    }
    
    private func createPostureDeviceCanvasNode() -> SCNNode {
        let canvas = SCNPlane(width: 1, height: 1.6)
        let material = SCNMaterial()
        
        if let image = postureDeviceImage {
            material.diffuse.contents = image
        } else {
            material.diffuse.contents = Color.clear
        }
        material.isDoubleSided = true
        material.transparencyMode = .dualLayer
        canvas.materials = [material]
        postureDeviceCanvasNode = SCNNode(geometry: canvas)
        postureDeviceCanvasNode.scale = SCNVector3(0.05,0.05,0.05)
        postureDeviceCanvasNode.position = SCNVector3(0.1, 0.1305, 0)
        
        return postureDeviceCanvasNode
    }
    
    func updateBattery() {
        batteryCanvasNode.removeFromParentNode()
        
        let newNode = createBatteryCanvasNode()
        parentNode.addChildNode(newNode)
        
        batteryCanvasNode = newNode
    }
    
    private func createBatteryCanvasNode() -> SCNNode {
        let canvas = SCNPlane(width: 1, height: 1.6)
        let material = SCNMaterial()
        
        if let image = batteryImage {
            material.diffuse.contents = image
        } else {
            material.diffuse.contents = UIColor.clear
        }
        material.isDoubleSided = true
        material.transparencyMode = .dualLayer
        canvas.materials = [material]
        batteryCanvasNode = SCNNode(geometry: canvas)
        batteryCanvasNode.scale = SCNVector3(0.05,0.05,0.05)
        batteryCanvasNode.position = SCNVector3(0.1, 0.046, 0)
        
        return batteryCanvasNode
    }
    
    func updatePosture() {
        postureCanvasNode.removeFromParentNode()
        
        let newPostureNode = createPostureCanvasNode()
        parentNode.addChildNode(newPostureNode)
        
        postureCanvasNode = newPostureNode
    }
    
    private func createPostureCanvasNode() -> SCNNode {
        let canvas = SCNPlane(width: 0.8, height: 0.8)
        let material = SCNMaterial()
        
        if let image = postureImage {
            material.diffuse.contents = image
        } else {
            material.diffuse.contents = UIColor.clear
        }
        
        if parent!.arSequence == .objectPlaced || parent!.arSequence == .contemplatingPlacement {
            material.diffuse.contents = UIImage(named: "posture")
        }
        material.isDoubleSided = true
        material.transparencyMode = .dualLayer
        canvas.materials = [material]
        postureCanvasNode = SCNNode(geometry: canvas)
        postureCanvasNode.scale = SCNVector3(0.05, 0.05, 0.05)
        postureCanvasNode.position = SCNVector3(0.1, 0.145 - 0.005 - 0.0032 - 0.0015, 0)
        
        return postureCanvasNode
    }
    
    func updateCamera() {
        cameraCanvasNode.removeFromParentNode()
        
        let newNode = createCameraCanvasNode()
        parentNode.addChildNode(newNode)
        
        cameraCanvasNode = newNode
    }
    
    private func createCameraCanvasNode() -> SCNNode {
        let canvas = SCNPlane(width: 0.8, height: 0.8)
        let material = SCNMaterial()
        
        if let image = cameraImage {
            material.diffuse.contents = image
        } else {
            material.diffuse.contents = UIImage(named: "SFcamera_slash")
        }
        material.isDoubleSided = true
        material.transparencyMode = .dualLayer
        canvas.materials = [material]
        cameraCanvasNode = SCNNode(geometry: canvas)
        cameraCanvasNode.scale = SCNVector3(0.05, 0.05, 0.05)
        cameraCanvasNode.position = SCNVector3(-0.1, 0.045, 0)
        
        return cameraCanvasNode 
    }
    
    func updateMap() {
        mapCanvasNode.removeFromParentNode()
        
        let newNode = createMapCanvasNode()
        parentNode.addChildNode(newNode)
        
        mapCanvasNode = newNode
    }
    
    private func createMapCanvasNode() -> SCNNode {
        let mapCanvas = SCNPlane(width: 1, height: 1.8)
        let mapCanvasMaterial = SCNMaterial()
        
        if let image = mapImage {
            mapCanvasMaterial.diffuse.contents = image
        } else {
            mapCanvasMaterial.diffuse.contents = UIColor.gray
        }
        mapCanvasMaterial.isDoubleSided = true
        mapCanvasMaterial.transparencyMode = .dualLayer
        mapCanvas.materials = [mapCanvasMaterial]
        mapCanvasNode = SCNNode(geometry: mapCanvas)
        mapCanvasNode.scale = SCNVector3(0.05, 0.05, 0.05)
        mapCanvasNode.position = SCNVector3(-0.1, 0.055, 0)
        
        return mapCanvasNode 
    }
    
    func updateSensor() {
        sensorCanvasNode.removeFromParentNode()
        
        let newNode = createSensorCanvasNode()
        parentNode.addChildNode(newNode)
        
        sensorCanvasNode = newNode
    }
    
    private func createSensorCanvasNode() -> SCNNode {
        let canvas = SCNPlane(width: 1, height: 0.7)
        let material = SCNMaterial()
        
        if let image = sensorImage {
            material.diffuse.contents = image
        } else {
            material.diffuse.contents = UIColor.gray
        }
        material.isDoubleSided = true
        material.transparencyMode = .dualLayer
        canvas.materials = [material]
        sensorCanvasNode = SCNNode(geometry: canvas)
        sensorCanvasNode.scale = SCNVector3(0.05, 0.05, 0.05)
        sensorCanvasNode.position = SCNVector3(-0.1, 0.1225, 0)
        
        return sensorCanvasNode 
    }
    
    func coachingOverlayViewDidDeactivate(_ coachingOverlayView: ARCoachingOverlayView ) {
        if parent!.arSequence == .arNotStarted {
            parent!.arSequence = .contemplatingPlacement
        }
    }    
    
    func setupFoucsNode(for arView: ARSCNView) {
        let spaceScale = (6400 / self.parent!.userParams.a) * 0.05
        self.arView = arView
        focusNode.isHidden = true
        focusNode = ARFunctions.getFocusNode(scale: spaceScale, a: self.parent!.userParams.a/6400,
                                             b: ARFunctions.calculateShortRadius(a: self.parent!.userParams.a/6400, e: self.parent!.userParams.e),
                                             i: self.parent!.userParams.i, 
                                             Ω: self.parent!.userParams.Ω)
        arView.scene.rootNode.addChildNode(focusNode)
        startPeriodicRaycast()
    }
    
    func startPeriodicRaycast() {
        timer?.invalidate()
        
        self.timer = Timer.scheduledTimer(withTimeInterval: 0.001, repeats: true) { [weak self] _ in
            if self!.parent!.arSequence == .contemplatingPlacement {
                self?.performRaycast()
            } else {
                self!.focusNode.isHidden = true
            }
        }
    }
    
    func stopRaycastTimer() {
        self.timer?.invalidate()
        timer = nil
    }
    
    func performRaycast() {
        
        guard let arView = arView else { return }
        
        let query = arView.raycastQuery(from: arView.center, allowing: .existingPlaneGeometry, alignment: .horizontal)
        guard let raycastQuery = query else {
            focusNode.isHidden = true
            return
        }
        let results = arView.session.raycast(raycastQuery)
        
        if let result = results.first {
            let transform = result.worldTransform
            let position = SCNVector3(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
            focusNode.position = position
            focusNode.isHidden = false
            self.focusPosition = position
            
            if let camera = arView.pointOfView {
                let relativePosition = SCNVector3(position.x - camera.position.x, position.y - camera.position.y, position.z - camera.position.z)
                var θ = atan(relativePosition.x / relativePosition.z)
                if relativePosition.z > 0 {
                    θ += .pi
                }
                focusNode.rotation = SCNVector4(0, 1, 0, θ)
            }
        } else {
            focusNode.isHidden = true
            self.focusPosition = nil
        }
    }
    
    func reDeployScene() {
        parent!.arSequence = .contemplatingPlacement
        parent!.scale = 0.5
        parentNode.removeFromParentNode()
        earthNode.removeFromParentNode()
        satelliteNode.removeFromParentNode()
        orbitNode.removeFromParentNode()
    }
    
    func deployScene(at position: SCNVector3) {
        let spaceScale = (6400 / self.parent!.userParams.a) * 0.05
        
        parentNode.enumerateChildNodes { (child, _) in
            child.removeFromParentNode()
        }
        
        let spaceNode = ARFunctions.getSpaceNode()
        orbitNode = ARFunctions.getOrbitNode(spaceScale: spaceScale, a: self.parent!.userParams.a/6400,
                                                 b: ARFunctions.calculateShortRadius(a: self.parent!.userParams.a/6400, e: self.parent!.userParams.e),
                                                 i: self.parent!.userParams.i, 
                                                 Ω: self.parent!.userParams.Ω)
        let chartDeviceNode = ARFunctions.getChartDeviceNode(image: chartImage)
        let postureDeviceNode = ARFunctions.getPostureDeviceNode()
        let mapDeviceNode = ARFunctions.getMapDevice(image: mapImage)
        let sensorDeviceNode = ARFunctions.getSensorDevice()
        let timerDeviceNode = ARFunctions.getTimerDeviceNode()
        self.satelliteNode = ARFunctions.getSatelliteNode(components: self.parent!.userComponents, params: self.parent!.userParams)
        self.satelliteNode.position = SCNVector3(0, 0.17/2, 0)
        
        let eulerXAngle = parent!.userParams.i * Float.pi / 180
        let eulerYAngle = (-1 * .pi/2) + (parent!.userParams.Ω * .pi/180)
        self.satelliteNode.eulerAngles = SCNVector3(eulerXAngle, eulerYAngle, 0)
        
        self.earthNode = ARFunctions.getEarthNode(spaceScale: spaceScale)
        
        //light
        let ambientLightNode = SCNNode()
        let ambientLight = SCNLight()
        ambientLight.type = .omni 
        ambientLight.intensity = 2000
        ambientLightNode.light = ambientLight
        ambientLightNode.position = SCNVector3(0,0,1)
        
        parentNode.addChildNode(spaceNode)
        parentNode.addChildNode(chartDeviceNode)
        parentNode.addChildNode(postureDeviceNode)
        parentNode.addChildNode(mapDeviceNode)
        parentNode.addChildNode(sensorDeviceNode)
        parentNode.addChildNode(timerDeviceNode)
        parentNode.addChildNode(satelliteNode)
        parentNode.addChildNode(earthNode)
        parentNode.addChildNode(ambientLightNode)
        
        
        updateCamera()
        updatePosture()
        updatePostureDevice()
        updateSensor()
        updateBattery()
        updateMap()
        updateTimer()
        
        updateAxisVector()
        
        parentNode.position = position
        parentNode.rotation = focusNode.rotation
        arView!.scene.rootNode.addChildNode(parentNode)
        
        
        
        parent!.arSequence = .objectPlaced
    }
    
    func triggerDeployScene() {
        guard let position = focusPosition else { return }
        DispatchQueue.main.async {
            self.deployScene(at: position)
        }
    }
    
    func updateScale(_ scale: Float) {
        focusNode.scale = SCNVector3(scale, scale, scale)
        parentNode.scale = SCNVector3(scale, scale, scale)
    } 
}
