import SwiftUI
import SceneKit
import Charts

struct CameraImageScene: UIViewRepresentable {
    @EnvironmentObject private var imageHolder: ImageHolder
    @EnvironmentObject private var userParams: UserParams
    @EnvironmentObject private var appState: AppState
    @State private var cameraOrbit = SCNNode()
    
    @Binding var isStartCamera: Bool
    @State var isFirst = true
    
    typealias UIViewType = SCNView
    
    func makeCoordinator() -> CameraCoordinator {
        CameraCoordinator()
    }
    
    func makeUIView(context: Context) -> SCNView {
        let scene = SCNScene()
        let scnView = SCNView()
        scnView.scene = scene
        
        scnView.backgroundColor = UIColor.clear
        scnView.isOpaque = false
        
        //earth
        let earth = SCNSphere(radius: 1)
        let earthMaterial = SCNMaterial()
        earthMaterial.diffuse.contents = UIImage(named: "earth_texture_map_with_clouds___1k___by_colourness_dg3wwrg-pre")
        earth.materials = [earthMaterial]
        context.coordinator.earthNode = SCNNode(geometry: earth)
        context.coordinator.earthNode.position = SCNVector3(0, 0, 0)
        scene.rootNode.addChildNode(context.coordinator.earthNode)
        
        //emission map
        let emissionSphere = SCNSphere(radius: 1.01)
        let emissionMaterial = SCNMaterial()
        emissionMaterial.diffuse.contents = UIImage(named: "emissionsGlobe")
        emissionMaterial.transparency = 0.25
        emissionMaterial.emission.contents = UIImage(named: "emissionsGlobe")
        emissionMaterial.emission.intensity = 5
        emissionSphere.materials = [emissionMaterial]
        context.coordinator.emissionSphereNode = SCNNode(geometry: emissionSphere)
        context.coordinator.emissionSphereNode.position = SCNVector3(0, 0, 0)
        scene.rootNode.addChildNode(context.coordinator.emissionSphereNode)
        
        let sunLightNode = SCNNode()
        let sunLight = SCNLight()
        sunLight.type = .directional
        sunLightNode.light = sunLight
        sunLightNode.look(at: SCNVector3(0,0,0))
        sunLightNode.position = SCNVector3(0, 0, 4)
        scene.rootNode.addChildNode(sunLightNode)
        
        cameraOrbit.position = SCNVector3(0, 0, 0)
        scene.rootNode.addChildNode(cameraOrbit)
        
        let cameraNode = SCNNode(geometry: SCNBox(width: 0.01, height: 0.01, length: 0.01, chamferRadius: 0))
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 2.05, y: 0, z: 0)
        cameraNode.look(at: SCNVector3(0,0,0))
        cameraOrbit.addChildNode(cameraNode)
        
        let eulerXAngle = userParams.i * Float.pi / 180
        let eulerYAngle = -1 * .pi/2 + userParams.Ω * .pi/180
        cameraOrbit.eulerAngles = SCNVector3(eulerXAngle, eulerYAngle, 0)
        
        return scnView
    }
    
    func updateUIView(_ uiView: UIViewType, context: Context) {
        DispatchQueue.main.async {
            if isStartCamera && isFirst {
                isFirst.toggle()
                
                let rotateAction = SCNAction.rotateBy(x: 0, y: 2 * .pi, z: 0, duration: 24)
                context.coordinator.earthNode.runAction(rotateAction)
                context.coordinator.emissionSphereNode.runAction(rotateAction)
                
                rotateCamera()
            }
            
            imageHolder.cameraImage = croppedCenterImage(from: uiView.snapshot())
        }
    }
    
    func rotateCamera() {
        let r = userParams.a * 1000
        let MG: Float = 4 * pow(10, 14)
        let ω: Float = sqrt(MG/pow(r, 3))
        let orbitTransform = cameraOrbit.presentation.worldTransform
        let axisVector = SCNVector3(orbitTransform.m21, orbitTransform.m22, orbitTransform.m23) 
        let rotateAction = SCNAction.rotate(by: CGFloat(ω * 24 * 60 * 60), around : axisVector, duration: 24)
        
        cameraOrbit.runAction(rotateAction)
    }
    
    func croppedCenterImage(from image: UIImage) -> UIImage? {
        guard let cgImage = image.cgImage else { return nil }
        
        let originalWidth = cgImage.width  
        let originalHeight = cgImage.height  
        let originalSize = min(originalWidth, originalHeight)  
        
        let cropSize = Int(CGFloat(originalSize) * 0.4)
        let cropX = (originalWidth - cropSize) / 2
        let cropY = (originalHeight - cropSize) / 2
        
        let cropRect = CGRect(x: cropX, y: cropY, width: cropSize, height: cropSize)
        
        guard let croppedCgImage = cgImage.cropping(to: cropRect) else {
            return nil
        }
        
        return UIImage(cgImage: croppedCgImage, scale: image.scale, orientation: image.imageOrientation)
    }
    
    class CameraCoordinator {
        var earthNode = SCNNode()
        var emissionSphereNode = SCNNode()
    }
}
