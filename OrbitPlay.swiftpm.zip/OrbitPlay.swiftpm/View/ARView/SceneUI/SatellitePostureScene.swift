import SwiftUI
import SceneKit
import Charts

struct SatellitePostureScene: UIViewRepresentable {
    @EnvironmentObject private var imageHolder: ImageHolder
    @EnvironmentObject private var userComponents: UserComponents
    @EnvironmentObject private var appState: AppState
    
    @Binding var worldPosition: SCNVector3
    @Binding var postureData: [PostureData]
    @Binding var eulerAngles: SCNVector3
    let ω: SCNVector3
    
    typealias UIViewType = SCNView
    
    func makeCoordinator() -> PostureCoordinator {
        PostureCoordinator()
    }
    
    func makeUIView(context: Context) -> SCNView {
        let scene = SCNScene()
        let scnView = SCNView()
        scnView.scene = scene
        scnView.allowsCameraControl = false
        
        let parentNode = context.coordinator.parentNode
        
        let satelliteNode = SCNNode()
        let spinAxisNode = SCNNode()
        
        scnView.backgroundColor = UIColor.clear
        scnView.isOpaque = false
        
        // body
        let bodyNode = getModel(userComponents.bodyMaterial)
        bodyNode.position = SCNVector3(x: 0, y: 0, z: 0)
        satelliteNode.addChildNode(bodyNode)
        
        // solarPanel
        let panelNodeL = getModel(userComponents.solarPanel)
        let panelNodeR = getModel(userComponents.solarPanel)
        panelNodeR.eulerAngles = SCNVector3(0, Float.pi, 0)
        panelNodeR.position = SCNVector3(-0.5, 0, 0)
        panelNodeL.position = SCNVector3(0.5, 0, 0)
        satelliteNode.addChildNode(panelNodeL)
        satelliteNode.addChildNode(panelNodeR)
        
        //circle axis
        let xRing = createRing(color: .red)
        xRing.eulerAngles = SCNVector3(0, 0, Float.pi / 2)
        spinAxisNode.addChildNode(xRing)
        
        let yRing = createRing(color: .green)
        spinAxisNode.addChildNode(yRing)
        
        let zRing = createRing(color: .blue)
        zRing.eulerAngles = SCNVector3(Float.pi / 2, 0, 0)
        spinAxisNode.addChildNode(zRing)
        
        parentNode.addChildNode(spinAxisNode)
        parentNode.addChildNode(satelliteNode)
        
        scene.rootNode.addChildNode(parentNode)
        
//        let pivot = SCNVector3(worldPosition.x, worldPosition.y, worldPosition.z)
        parentNode.eulerAngles = eulerAngles
        
        
        let ambientLight = SCNLight()
        ambientLight.type = .ambient
        ambientLight.intensity = 500
        let ambientLightNode = SCNNode()
        ambientLightNode.light = ambientLight
        scene.rootNode.addChildNode(ambientLightNode)
        
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 11)
        scene.rootNode.addChildNode(cameraNode)
        
        return scnView
    }
    
    func updateUIView(_ uiView: SCNView, context: Context) {
        let parentNode = context.coordinator.parentNode
        parentNode.eulerAngles = eulerAngles
        
        if appState.arSequence == .missionStart {
            DispatchQueue.main.async {
                let vector = parentNode.eulerAngles
                postureData.append(PostureData(x: vector.x, y: vector.y, z: vector.z))
                imageHolder.postureImage = uiView.snapshot()
            }
        }
    }

    func createRing(color: UIColor) -> SCNNode {
        let torus = SCNTorus(ringRadius: 4, pipeRadius: 0.07)
        torus.firstMaterial?.diffuse.contents = color
        return SCNNode(geometry: torus)
    }
    
    class PostureCoordinator {
        let parentNode = SCNNode()
        var takePhoto = true
    }
}

struct PostureDeviceView: View {
    let data: [PostureData]
    
    var body: some View {
        VStack {
            Rectangle()
                .frame(height: 3)
                .frame(maxWidth: .infinity)
                .foregroundStyle(Color.grayBlack)
                .overlay(Text("Attitude").bold().font(.largeTitle).foregroundStyle(.white))
                .padding(.bottom, 30)
            
            HStack(spacing: 0) {
                Text("X")
                    .foregroundStyle(Color(UIColor(.red)))
                    .font(.largeTitle)
                if let value = data.last {
                    Text(" : \(String(format: "%.1f", value.x * 180 / .pi))°")
                        .foregroundStyle(.white)
                } else {
                    Text(" : --")
                        .foregroundStyle(.white)
                }
                
                Spacer()
                
                Text("Y")
                    .foregroundStyle(Color(UIColor.green))
                    .font(.largeTitle)
                if let value = data.last {
                    Text(" : \(String(format: "%.1f", value.y * 180 / .pi))°")
                        .foregroundStyle(.white)
                } else {
                    Text(" : --")
                        .foregroundStyle(.white)
                }
                
                Spacer()
                
                Text("Z")
                    .foregroundStyle(Color(UIColor.blue))
                    .font(.largeTitle)
                if let value = data.last {
                    Text(" : \(String(format: "%.1f", value.z * 180 / .pi))°")
                        .foregroundStyle(.white)
                } else {
                    Text(" : --")
                        .foregroundStyle(.white)
                }
            }
            .bold()
            .font(.title)
            
            Spacer()
                .frame(height: 450)
            
            HStack {
                Text("X")
                    .font(.largeTitle)
                    .foregroundStyle(.white)
                    .bold()
                    .padding(.trailing)
                Chart() {
                    ForEach(Array(data.enumerated()), id: \.offset) { index, value in
                        LineMark(
                            x: .value("t", index),
                            y: .value("x", value.x * 180 / .pi)
                        )
                        .foregroundStyle(Color(UIColor.red))
                        .lineStyle(StrokeStyle(lineWidth: 4))
                    }
                }
                .chartYScale(domain: -180...180)
                .chartXAxis(.hidden)
                .chartYAxis {
                    AxisMarks(values: .stride(by: 90)) { value in
                        AxisGridLine(stroke: StrokeStyle(lineWidth: 2))
                            .foregroundStyle(Color.grayBlack)
                        
                        AxisValueLabel() {
                            if let intValue = value.as(Int.self) {
                                Text("\(intValue)°")
                            }
                        }
                        .foregroundStyle(Color.white)
                    }
                }
            }
            
            HStack {
                Text("Y")
                    .font(.largeTitle)
                    .foregroundStyle(.white)
                    .bold()
                    .padding(.trailing)
                Chart() {
                    ForEach(Array(data.enumerated()), id: \.offset) { index, value in
                        LineMark(
                            x: .value("t", index),
                            y: .value("y", value.y * 180 / .pi)
                        )
                        .foregroundStyle(Color(UIColor.green))
                        .lineStyle(StrokeStyle(lineWidth: 4))
                    }
                }
                .chartYScale(domain: -180...180)
                .chartXAxis(.hidden)
                .chartYAxis {
                    AxisMarks(values: .stride(by: 90)) { value in
                        AxisGridLine(stroke: StrokeStyle(lineWidth: 2))
                            .foregroundStyle(Color.grayBlack)
                        
                        AxisValueLabel() {
                            if let intValue = value.as(Int.self) {
                                Text("\(intValue)°")
                            }
                        }
                        .foregroundStyle(Color.white)
                    }
                }
            }
            
            HStack {
                Text("Z")
                    .font(.largeTitle)
                    .foregroundStyle(.white)
                    .bold()
                    .padding(.trailing)
                Chart() {
                    ForEach(Array(data.enumerated()), id: \.offset) { index, value in
                        LineMark(
                            x: .value("t", index),
                            y: .value("z", value.z * 180 / .pi)
                        )
                        .foregroundStyle(Color(UIColor.blue))
                        .lineStyle(StrokeStyle(lineWidth: 4))
                    }
                }
                .chartYScale(domain: -180...180)
                .chartXAxis(.hidden)
                .chartYAxis {
                    AxisMarks(values: .stride(by: 90)) { value in
                        AxisGridLine(stroke: StrokeStyle(lineWidth: 2))
                            .foregroundStyle(Color.grayBlack)
                        
                        AxisValueLabel() {
                            if let intValue = value.as(Int.self) {
                                Text("\(intValue)°")
                            }
                        }
                        .foregroundStyle(Color.white)
                    }
                }
            }
            
        }
        .padding(50)
        .frame(width: 500 ,height: 800)
    }
}



extension SCNVector3 {
    func length() -> Float {
        return sqrt(x*x + y*y + z*z)
    }
    
    func normalized() -> SCNVector3 {
        let len = self.length()
        return (len > 0) ? self / len : self
    }
    
    static func /(vector: SCNVector3, scalar: Float) -> SCNVector3 {
        return SCNVector3(vector.x / scalar, vector.y / scalar, vector.z / scalar)
    }
    
    static func cross(_ a: SCNVector3, _ b: SCNVector3) -> SCNVector3 {
        return SCNVector3(
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x
        )
    }
    
    func dot(_ other: SCNVector3) -> Float {
        return x * other.x + y * other.y + z * other.z
    }
}
