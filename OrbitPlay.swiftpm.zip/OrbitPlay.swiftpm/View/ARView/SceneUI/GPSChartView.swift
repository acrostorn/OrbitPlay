import SwiftUI
import Charts

struct mapDeviceView: View {
    let data: [MapPlotData]
    
    var body: some View {
        VStack {
            Rectangle()
                .frame(height: 3)
                .foregroundStyle(Color.grayBlack)
                .overlay(Text("Position").bold().font(.largeTitle).foregroundStyle(.white))
                .padding(.bottom, 40)
            
            Image("world.topo.200406.3x5400x2700")
                .resizable()
                .aspectRatio(contentMode: . fit)
                .overlay(GPSChart(data: data))
                .padding(.bottom)
            
            Spacer()
                .frame(width: 400, height: 400)
            
            Spacer()
            
            VStack {
                HStack{
                    Text("Latitude :")
                    Spacer()
                    if let lat = data.last?.lat {
                        Text("\(lat)")
                    } else {
                        Text("--")
                    }
                }
                HStack{
                    Text("Longitude :")
                    Spacer()
                    if let lon = data.last?.lon {
                        Text("\(lon)")
                    } else {
                        Text("--")
                    }
                }
            }
            .font(.title)
            .bold()
            .foregroundStyle(.white)
        }
        .padding(50)
        .frame(width: 500, height: 900)
    }
}

struct GPSChart: View {
    let data: [MapPlotData]
    
    var body: some View {
        Chart(data) { point in
            LineMark(
                x: .value("Longitude", point.lon),
                y: .value("Latitude", point.lat)
            )
            .interpolationMethod(.catmullRom)
            .foregroundStyle(by: .value("Segment", point.segmentID))
        }
        .chartXScale(domain: -180...180)
        .chartYScale(domain: -90...90)
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .chartLegend(.hidden)
    }
}
