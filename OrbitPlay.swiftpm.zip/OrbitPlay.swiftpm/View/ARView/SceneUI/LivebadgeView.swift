import SwiftUI

struct LiveBadgeView: View {
    var body: some View {
        HStack {
            Circle().fill(.red)
                .padding(.trailing, 10)
                .padding(.vertical)
            VStack(alignment: .leading) {
                Text("Live")
                    .foregroundStyle(.white)
                    .font(.largeTitle)
                    .bold()
                Text("from Satellite Camera")
                    .foregroundStyle(Color.grayBlack)
                    .font(.headline)
            }
        }
        .padding(5)
        .frame(width: 300, height: 100) 
    }
}
