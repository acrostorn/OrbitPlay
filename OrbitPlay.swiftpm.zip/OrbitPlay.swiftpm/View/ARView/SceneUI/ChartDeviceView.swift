import SwiftUI
import Charts

struct ChartDeviceView: View {
    @EnvironmentObject private var appState: AppState
    @State var data: [ChartData]
    private let consumingData: [(String, Int)] = {
        let dif = Int.random(in: -1...1)
        
        return [
            ("Communication System", 25 + dif*2),
            ("Camera", 20 - dif),
            ("Attitude Determination", 15 + dif*2),
            ("Onboard Computer", 15 - dif*2),
            ("GNSS Receiver", 10 + dif),
            ("Thermal Control System", 10 - dif*2),
            ("Temperature Sensor", 5 + dif)
        ]
    }()
    
    var body: some View {
        VStack {
            Rectangle()
                .frame(height: 3)
                .foregroundStyle(Color.grayBlack)
                .overlay(Text("Battery").bold().font(.largeTitle).foregroundStyle(.white))
                .padding(.bottom, 30)
            
            Text("\(Int(data.last!.y)) %")
                .bold()
                .font(.title)
                .padding(.bottom)
                .foregroundStyle(Color.green)
            
            ChartComponent(data: data)
                .frame(height: 200)
                .padding(.bottom)
            
            Rectangle()
                .frame(height: 3)
                .foregroundStyle(Color.grayBlack)
                .padding(.bottom, 30)
            
            VStack {
                ForEach(consumingData, id: \.self.0) { item, value in
                    HStack {
                        Text(item)
                        Spacer()
                        if data.contains(where: { $0.y != 100 }) {
                            Text("\(value)%")
                        } else {
                            Text("--%")
                        }
                    }
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundStyle(.white)
                    .padding(.bottom, 10)
                }
            }
            .frame(maxHeight: .infinity)
        }
        .padding(50)
        .frame(width: 500 ,height: 800)
    }
}


struct ChartComponent: View {
    @State var data: [ChartData]
    
    var body: some View {
        VStack {
            chartView()   
        }
    }
    
    func chartView() -> some View {
        VStack {
            Chart(data) { point in
                BarMark(
                    x: .value("X", point.x),
                    y: .value("Y", point.y)
                )
            }
            .foregroundStyle(.green)
            .chartXAxis {
                AxisMarks {
                    AxisValueLabel()
                        .foregroundStyle(Color.white)
                }
            }
            .chartXScale(domain: (data.suffix(15).first?.x ?? 0)...(data.suffix(15).last?.x ?? 15))
            .chartXAxis(.hidden)
            .chartYAxis(.hidden)
        }
    }
}
