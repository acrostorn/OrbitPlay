import SwiftUI
import Charts

struct SensorDeviceView: View {
    let data: [SensorData]
    
    var lastFifteenData: [SensorData] {
        Array(data.suffix(15))
    }
    
    var body: some View {
        VStack {
            Rectangle()
                .frame(height: 3)
                .foregroundStyle(Color.grayBlack)
                .overlay(Text("Temperature").bold().font(.largeTitle).foregroundStyle(.white))
                .padding(.bottom, 30)
                .padding(.horizontal, 40)
            
            Chart(lastFifteenData) { point in
                LineMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("external", point.externalValue)
                )
                .interpolationMethod(.catmullRom)
                .foregroundStyle(by: .value("Series", "External"))
                
                PointMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("external", point.externalValue)
                )
                .foregroundStyle(.orange)
                
                LineMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("internal", point.internalValue)
                )
                .interpolationMethod(.catmullRom)
                .foregroundStyle(by: .value("Series", "Internal"))
                
                PointMark(
                    x: .value("Index", point.id.uuidString),
                    y: .value("internal", point.internalValue)
                )
                .foregroundStyle(.blue)
            }
            .chartForegroundStyleScale([
                "External": .orange,
                "Internal": .blue
            ])
            .chartYScale(domain: -170...170)
            .chartYAxis {
                AxisMarks(values: .stride(by: 50)) { value in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel {
                        if let intValue = value.as(Int.self) {
                            Text("\(intValue) °C")
                                .foregroundStyle(.white)
                                .bold()
                        }
                    }
                }
            }
            .chartXAxis(.hidden)
            .chartLegend(.hidden)
            .overlay(alignment: .bottomLeading) {
                HStack {
                    HStack {
                        Circle()
                            .fill(Color.orange)
                            .frame(width: 10, height: 10)
                        Text("External")
                            .foregroundColor(.white)
                            .font(.system(size: 20, weight: .bold))
                    }
                    HStack {
                        Circle()
                            .fill(Color.blue)
                            .frame(width: 10, height: 10)
                        Text("Internal")
                            .foregroundColor(.white)
                            .font(.system(size: 20, weight: .bold))
                    }
                }
                .offset(y: 25)
            }
            .padding(.trailing, 10)
            .padding(.leading, 50)
        }
        .padding(.vertical, 50)
        .frame(width: 500, height: 350)
    }
}
