import SwiftUI

struct TimerDeviceView: View {
    let progress: Float
    
    var body: some View {
        VStack {
            let time = Int(24 * 60 * 60 * progress)
            let h = Int(time/3600)
            let hs = h*3600
            let m = Int((time-hs)/60)
            let ms = m * 60
            let s = Int(time-hs-ms)
            
            HStack(alignment: .bottom, spacing: 3) {
                Text("\(h)")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                Text("H")
                Text("\(m)")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                Text("M")
                Text("\(s)")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                Text("S")
            }
            .foregroundStyle(Color.white)
            .bold()
            .scaleEffect(2)
            
            ZStack(alignment: .leading) {
                Capsule()
                    .frame(width: 400, height: 10)
                    .foregroundStyle(.gray)
                Capsule()
                    .frame(height: 10)
                    .foregroundStyle(.green)
                    .frame(width: CGFloat(400 * progress))
            }
            .scaleEffect(1)
        }
        .padding(50)
        .frame(width: 500, height: 250)
    }
}
