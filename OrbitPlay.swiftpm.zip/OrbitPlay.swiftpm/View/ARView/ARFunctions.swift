import SwiftUI
import SceneKit

struct ARFunctions {
    @MainActor
    static func render(_ view: some View) -> UIImage? {
        let renderer = ImageRenderer(content: view)        
        renderer.scale = 5
        
        return renderer.uiImage
    }
    
    static func getFocusNode(scale: Float, a: Float, b: Float, i: Float, Ω: Float) -> SCNNode {
        let parentNode = SCNNode()
        
        //wire material
        let wireMaterial = SCNMaterial()
        wireMaterial.fillMode = .lines
        wireMaterial.transparency = 0.5
        
        //indicator ring
        let ring = SCNTorus(ringRadius: 0.05, pipeRadius: 0.002)
        ring.materials = [wireMaterial]
        let ringNode = SCNNode(geometry: ring)        
        
        //wire earth
        let virtualEarth = SCNSphere(radius: 1)
        virtualEarth.materials = [wireMaterial]
        let virtualEarthNode = SCNNode(geometry: virtualEarth)
        virtualEarthNode.position = SCNVector3(0,0.17/2,0)
        virtualEarthNode.scale = SCNVector3(scale, scale, scale)
        
        //chartDevice
        let chartBackground = SCNBox(width: 1, height: 1.6, length: 0.1, chamferRadius: 0.05)
        chartBackground.materials = [wireMaterial]
        let chartBackgroundNode = SCNNode(geometry: chartBackground)
        chartBackgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        chartBackgroundNode.position = SCNVector3(0.1, 0.046, -0.00001-0.0025)
        
        //postureDevice
        let postureBackground = SCNBox(width: 1, height: 1.6, length: 0.1, chamferRadius: 0.05)
        postureBackground.materials = [wireMaterial]
        let postureBackgroundNode = SCNNode(geometry: postureBackground)
        postureBackgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        postureBackgroundNode.position = SCNVector3(0.1, 0.1305, -0.00001-0.0025)
        
        //mapDevice
        let mapBackground = SCNBox(width: 1, height: 1.8, length: 0.1, chamferRadius: 0.05)
        mapBackground.materials = [wireMaterial]
        let mapBackgroundNode = SCNNode(geometry: mapBackground)
        mapBackgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        mapBackgroundNode.position = SCNVector3(-0.1, 0.055, -0.00001-0.0025)
        
        //sensorDevice
        let sensorBackground = SCNBox(width: 1, height: 0.7, length: 0.1, chamferRadius: 0.05)
        sensorBackground.materials = [wireMaterial]
        let sensorBackgroundNode = SCNNode(geometry: sensorBackground)
        sensorBackgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        sensorBackgroundNode.position = SCNVector3(-0.1, 0.1225, -0.00001-0.0025)
        
        //timerDevice
        let timerBackground = SCNBox(width: 1, height: 0.5, length: 0.1, chamferRadius: 0.05)
        timerBackground.materials = [wireMaterial]
        let timerBackgroundNode = SCNNode(geometry: timerBackground)
        timerBackgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        timerBackgroundNode.position = SCNVector3(-0.1, 0.1575, -0.00001-0.0025)
        
        parentNode.addChildNode(ringNode)
        parentNode.addChildNode(virtualEarthNode)
        parentNode.addChildNode(chartBackgroundNode)
        parentNode.addChildNode(postureBackgroundNode)
        parentNode.addChildNode(mapBackgroundNode)
        parentNode.addChildNode(sensorBackgroundNode)
        parentNode.addChildNode(timerBackgroundNode)
        
        return parentNode
    }
    
    static func getSpaceNode() -> SCNNode {
        let parentNode = SCNNode()
        
        //sun light
        let sunLightNode = SCNNode()
        let sunLight = SCNLight()
        sunLight.type = .directional
        sunLight.categoryBitMask = 2
        sunLightNode.light = sunLight
        sunLightNode.look(at: SCNVector3(0,0,0))
        sunLightNode.position = SCNVector3(0, 0.432, 1)
        
        parentNode.addChildNode(sunLightNode)
        
        return parentNode
    }
    
    static func getOrbitNode(spaceScale: Float, a: Float, b: Float, i: Float, Ω: Float) -> SCNNode {
        let parentNode = SCNNode()
        
        //orbit
        let orbitNode = ARFunctions.createAROrbitNode(a: a, b: ARFunctions.calculateShortRadius(a: a, e: 0), i: i, Ω: Ω)  
        orbitNode.scale = SCNVector3(spaceScale, spaceScale, spaceScale)
        orbitNode.position = SCNVector3(0, 0.17/2, 0)
        orbitNode.name = "orbit"
        
        parentNode.addChildNode(orbitNode)
        
        return parentNode
    }
    
    static func getEarthNode(spaceScale: Float) -> SCNNode {
        let parentNode = SCNNode()
        
        //earth
        let earth = SCNSphere(radius: 1)
        let earthMaterial = SCNMaterial()
        earthMaterial.diffuse.contents = UIImage(named: "earth_texture_map_with_clouds___1k___by_colourness_dg3wwrg-pre")
        earth.materials = [earthMaterial]
        let earthNode = SCNNode(geometry: earth)
        earthNode.scale = SCNVector3(spaceScale, spaceScale, spaceScale)
        earthNode.position = SCNVector3(0, 0.17/2, 0)
        earthNode.categoryBitMask = 2
        
        //emission map
        let emissionSphere = SCNSphere(radius: 1.01)
        let emissionMaterial = SCNMaterial()
        emissionMaterial.diffuse.contents = UIImage(named: "emissionsGlobe")
        emissionMaterial.transparency = 0.25
        emissionMaterial.emission.contents = UIImage(named: "emissionsGlobe")
        emissionMaterial.emission.intensity = 3
        emissionSphere.materials = [emissionMaterial]
        let emissionSphereNode = SCNNode(geometry: emissionSphere)
        emissionSphereNode.scale = SCNVector3(spaceScale, spaceScale, spaceScale)
        emissionSphereNode.position = SCNVector3(0, 0.17/2, 0)
        
        parentNode.addChildNode(earthNode)
        parentNode.addChildNode(emissionSphereNode)
        
        return parentNode
    }
    
    static func getChartDeviceNode(image chartImage: UIImage?) -> SCNNode {
        let parentNode = SCNNode()
        
        //background
        let background = SCNBox(width: 1, height: 1.6, length: 0.1, chamferRadius: 0.05)
        background.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        let backgroundNode = SCNNode(geometry: background)
        backgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        backgroundNode.position = SCNVector3(0.1, 0.046, -0.00001-0.0025)
        
        parentNode.addChildNode(backgroundNode)
        
        return parentNode
    }
    
    static func getPostureDeviceNode() -> SCNNode {
        let parentNode = SCNNode()
        
        let background = SCNBox(width: 1, height: 1.6 , length: 0.1, chamferRadius: 0.05)
        background.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        let backgroundNode = SCNNode(geometry: background)
        backgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        backgroundNode.position = SCNVector3(0.1, 0.1305, -0.00001-0.0025)
        
        parentNode.addChildNode(backgroundNode)
        
        return parentNode
    }
    
    static func getMapDevice(image mapImage: UIImage?) -> SCNNode {
        let parentNode = SCNNode()
        
        //background
        let background = SCNBox(width: 1, height: 1.8, length: 0.1, chamferRadius: 0.05)
        background.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        let backgroundNode = SCNNode(geometry: background)
        backgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        backgroundNode.position = SCNVector3(-0.1, 0.055, -0.0001-0.0025) 
        
        parentNode.addChildNode(backgroundNode)
        
        return parentNode
    }
    
    static func getSensorDevice() -> SCNNode {
        let parentNode = SCNNode()
        
        //background
        let background = SCNBox(width: 1, height: 0.7, length: 0.1, chamferRadius: 0.05)
        background.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        let backgroundNode = SCNNode(geometry: background)
        backgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        backgroundNode.position = SCNVector3(-0.1, 0.1225, -0.0001-0.0025) 
        
        parentNode.addChildNode(backgroundNode)
        
        return parentNode
    }
    
    static func getTimerDeviceNode() -> SCNNode {
        let parentNode = SCNNode()
        
        //background
        let background = SCNBox(width: 1, height: 0.5, length: 0.1, chamferRadius: 0.05)
        background.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        let backgroundNode = SCNNode(geometry: background)
        backgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        backgroundNode.position = SCNVector3(-0.1, 0.1575, -0.00001-0.0025)
        
        parentNode.addChildNode(backgroundNode)
        
        return parentNode
    }
    
    static func getSatelliteNode(components: UserComponents, params: UserParams) -> SCNNode {
        let parentNode = SCNNode()
        let satelliteNode = SCNNode()
        
        //body
        let bodyNode = getModel(components.bodyMaterial, inAR: true)
        bodyNode.position = SCNVector3(x:0, y:0, z:0)
        satelliteNode.addChildNode(bodyNode)
        
        //solarPanel
        let panelNodeL = getModel(components.solarPanel, inAR: true)
        let panelNodeR = getModel(components.solarPanel, inAR: true)
        panelNodeR.eulerAngles = SCNVector3(0, Float.pi, 0)
        panelNodeR.position = SCNVector3(-0.5, 0, 0)
        panelNodeL.position = SCNVector3(0.5, 0, 0)
        satelliteNode.addChildNode(panelNodeL)
        satelliteNode.addChildNode(panelNodeR)
        
        satelliteNode.scale = SCNVector3(0.0015, 0.0015, 0.0015)
        satelliteNode.eulerAngles = SCNVector3(0, Float.pi, 3 * Float.pi / 2)
        satelliteNode.position = SCNVector3(0.05, 0, 0)
        satelliteNode.name = "satellite"
        
        parentNode.addChildNode(satelliteNode)
        
        parentNode.position = SCNVector3(0, 0, 0)
        
        return parentNode
    }
    
    static func getBadgeNode(badgeImage: UIImage?) -> SCNNode {
        let parentNode = SCNNode()
        
        let canvas = SCNPlane(width: 0.3, height: 0.1)
        let canvasMaterial = SCNMaterial()
        if let image = badgeImage {
            canvasMaterial.diffuse.contents = image
        } else {
            canvasMaterial.diffuse.contents = UIColor.clear
        }
        canvas.materials = [canvasMaterial]
        let canvasNode = SCNNode(geometry: canvas)
        canvasNode.scale = SCNVector3(0.05, 0.05, 0.05)
        canvasNode.position = SCNVector3(-0.11135, 0.05875 + 0.0025, 0.0001)
        parentNode.addChildNode(canvasNode)
        
        let background = SCNBox(width: 0.3, height: 0.1, length: 0.00001, chamferRadius: 0.1)
        background.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        let backgroundNode = SCNNode(geometry: background)
        backgroundNode.scale = SCNVector3(0.05, 0.05, 0.05)
        backgroundNode.position = SCNVector3(-0.11135, 0.05875 + 0.0025, -0.00001 - 0.00001/2 + 0.0001)
        
        parentNode.addChildNode(backgroundNode)
        
        return parentNode
    }
    
    static func calculateShortRadius(a: Float, e: Float) -> Float {
        let b: Float
        b = a * sqrt(1 - powf(e, 2))
        return b
    }
    
    static func calculateVernalEquinoxLongitude(date: Date) -> Float {
        let λ: Float
        λ = 30
        return λ
    }
    
    static func createAROrbitNode(a: Float, b: Float, i: Float, Ω: Float) -> SCNNode {
        let segments = 100
        var vertices = [SCNVector3]()
        
        let width: Float = a
        let height: Float = b
        
        for i in 0...segments {
            let angle = Float(i) * (2.0 * Float.pi / Float(segments))
            let x = width * cos(angle)
            let z = height * sin(angle)
            vertices.append(SCNVector3(x, 0, z))
        }
        
        let vertexSource = SCNGeometrySource(vertices: vertices)
        
        var indices = [Int32]()
        for i in 0..<segments {
            indices.append(Int32(i))
            indices.append(Int32(i + 1))
        }
        
        indices.append(Int32(segments))
        indices.append(0)
        
        let element = SCNGeometryElement(indices: indices, primitiveType: .line)
        let geometry = SCNGeometry(sources: [vertexSource], elements: [element])
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.cyan
        material.emission.contents = UIColor.cyan.withAlphaComponent(0.9)
        geometry.materials = [material]
        let tmpNode = SCNNode(geometry: geometry)
        
        let eulerXAngle = i * Float.pi / 180
        let eulerYAngle = -90 + Ω * Float.pi / 180
        tmpNode.eulerAngles = SCNVector3(x: eulerXAngle, y: eulerYAngle, z: 0)
        
        return tmpNode
    }
}
