//
//  ContentView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/09.

import SwiftUI

struct ContentView : View {
    var body: some View {
        TitleView()
    }
}
