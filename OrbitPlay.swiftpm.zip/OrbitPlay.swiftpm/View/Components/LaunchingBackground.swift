import SwiftUI

struct LaunchingBackground: View {
    @Binding var isLaunching: Bool
    private let colorSet = Gradient(colors: [Color.red, Color.orange, Color.yellow, Color.red])
    
    @State private var flameOffset: CGFloat = -1
    
    var body: some View {
        ZStack {
            Group {
                GeometryReader { geometry in
                    LinearGradient(
                        gradient: colorSet,
                        startPoint: UnitPoint(x: 0.5, y: 1 + flameOffset),
                        endPoint: .top
                    )
                    .blur(radius: 50) 
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .animation(
                        !isLaunching ? .default : Animation.easeInOut(duration: 1).repeatForever(autoreverses: true),
                        value: flameOffset
                    )
                    .onAppear {
                        if !isLaunching {
                            flameOffset = 0.05
                        }
                    }
                }
            }
            .opacity(!isLaunching ? 0 : 1)
            .animation(Animation.easeOut(duration: 0.5), value: !isLaunching)
            
            Rectangle()
                .fill(.thickMaterial)
                .environment(\.colorScheme, .dark)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .opacity(!isLaunching ? 0 : 1)
                .animation(Animation.easeOut(duration: 0.5), value: !isLaunching)
        }
    }
}
