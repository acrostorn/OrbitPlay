import SwiftUI

struct NavigationBubble: View {
    @Binding var isStart: Bool
    @Binding var isAnimating: Bool
    @Binding var launchingFlag: Bool
    @State private var messageText = "Hello!! Welcome to Orbit Play!! From now, you will experience whole artificial satellite unnyou!"
    @EnvironmentObject private var appState: AppState
    @Binding var isCircle: Bool
    @State private var progress: CGFloat = 1
    @State private var angleOffset: Double = 0
    @State private var fireAngleOffset: Double = 0
    @State private var glowAmount: CGFloat = 20
    @State private var fireAmount: CGFloat = 0.0
    
    @State var isLaunching = false
    private let blueGradient: Gradient = Gradient(colors: [Color.blue, Color.cyan, Color.teal, Color.blue])
    private let redGradient: Gradient = Gradient(colors: [Color.red, Color.orange, Color.red, Color.orange, Color.red])
    
    @State var resetAnimation = false
    
    var body: some View {
        
        ZStack {
            RoundedRectangle(cornerRadius: isCircle ? 20 : 25)
                .fill(isCircle && appState.appSequence == .tapMe ? LinearGradient(gradient: Gradient(colors: [.clear]), startPoint: .leading, endPoint: .trailing) 
                      : LinearGradient(
                        gradient: [.launchingNow, .goForLaunch].contains(appState.appSequence) ? redGradient : blueGradient,
                        startPoint: .leading,
                        endPoint: .trailing
                      )
                )
                .frame(minWidth: 40, minHeight: 40)
                .frame(maxWidth: isCircle ? 40 : .infinity - 330, maxHeight: 25)
                .animation(.spring(duration: 1.0), value: isCircle) 
                .shadow(color: [.launchingNow, .goForLaunch].contains(appState.appSequence) ? Color.red.opacity(0.6) : Color.blue.opacity(0.6), radius: glowAmount)
                
            RoundedRectangle(cornerRadius: isCircle ? 50 : 25)
                .fill(.thinMaterial)
                .environment(\.colorScheme, .dark)
                .frame(minWidth: 100, minHeight: 100)
                .frame(maxWidth: isCircle ? 100 : .infinity, maxHeight: 100)
                .overlay(
                    RoundedRectangle(cornerRadius: isCircle ? 50 : 25)
                        .trim(from: 0, to: progress)
                        .stroke(
                            AngularGradient(
                                gradient: appState.appSequence == .launchingNow ? redGradient : blueGradient,
                                center: .center,
                                startAngle: .degrees(appState.appSequence == .launchingNow ? fireAngleOffset : angleOffset),
                                endAngle: .degrees(appState.appSequence == .launchingNow ? fireAngleOffset + 360 : angleOffset + 360)
                            ),
                            style: StrokeStyle(lineWidth: 10, lineCap: .round)
                        )
                        .rotationEffect(.degrees(180)) 
                        .animation(.spring(duration: 1.0), value: progress)
                        .shadow(color: appState.appSequence == .launchingNow ? Color.red.opacity(0.8) : Color.blue.opacity(0.8), radius: appState.appSequence == .launchingNow ? fireAmount : glowAmount)
                        .frame(minWidth: 100, minHeight: 100)
                        .onAppear {
                            print(appState.appSequence)
                            if [.appStart].contains(appState.appSequence) {
                                animateGradient()
                                animateGlow()
                            }
                        }
                )
                .animation(.spring(duration: 1.0), value: isCircle)
                .onTapGesture {
                    if appState.appSequence == .tapMe && !isStart{
                        isCircle.toggle()
                        progress = progress==1 ? 0 : 1
                        appState.appSequence = .hello
                    } else if appState.appSequence == .launchingNow && !isLaunching{
                        isCircle.toggle()
                        progress = progress==1 ? 0 : 1
                        appState.appSequence = .launchSucceed
                        launchingFlag = false
                    }
                }
                
            if !isCircle || appState.appSequence == .launchingNow {
                if appState.appSequence != .launchingNow {
                    TypeWriterTextView(
                        text: messageText,
                        speed: 0.008,
                        isStart: $isStart,
                        isAnimating: $isAnimating,
                        launchingFlag: $launchingFlag
                    )   
                } else {
                    TypeWriterTextView(
                        text: messageText,
                        speed: 0.1,
                        isStart: $isLaunching,
                        isAnimating: $isAnimating,
                        launchingFlag: $launchingFlag
                    )   
                    .offset(y: -115)
                }
            }
        }
        .onChange(of: isCircle) {
            //isCircleであってはならない本来は仮にこうしてるだけ
            //isStart.toggle()
            if appState.appSequence == .launchingNow {
                progress = progress==1 ? 0 : 1
                animateFireGlow()
                animateFireGradient()
            }
        }
        .onChange(of: appState.appSequence) {
            switch appState.appSequence {
            case .hello:
                messageText = "Hello, Mission Director! I'm your OrbitPlay assistant, here to help you manage the space mission."
            case .goDashBoard:
                messageText = "Preparing your system... In OrbitPlay, you'll experience what it's like to design and operate your own satellite. Let's begin!"
            case .naviToSatellite:
                messageText = "Your journey starts now. Tap the 'Assemble Satellite' button to begin building your satellite."
            case .naviToOrbit:
                messageText = "Great progress! Now, let's design your satellite's orbit. Tap 'Design Orbit' to proceed."
            case .goForLaunch:
                messageText = "Excellent work! Everything is set. The moment has arrived—let’s launch and begin your mission!"
            case .launchingNow:
                messageText = "       LAUNCHING NOW . . . \n                 \n TAP ME"
            case .launchSucceed:
                messageText = "Great job! Your satellite has been successfully launched and is now in orbit!"
            case .goAR:
                messageText = "To access the Mission Control Center, find a flat surface and deploy it using AR."
            case .thankYou:
                messageText = ""
            case .continuePlaying:
                messageText = "Mission complete! You can continue optimizing your satellite and orbit to modify simulation outcomes. Until next time!"
            default:
                return
            }
        }
    }
    
    private func animateGradient() {
        angleOffset = 0
        withAnimation(.linear(duration: 4.0).repeatForever(autoreverses: false)) {
            angleOffset += 360
        }
    }
    
    private func animateGlow() {
        glowAmount = 20
        withAnimation(.easeInOut(duration: 0.75).repeatForever(autoreverses: true)) {
            glowAmount = 0
        }
    }
    
    private func animateFireGradient() {
        fireAngleOffset = 0
        withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) {
            fireAngleOffset += 360
        }
    }
    
    private func animateFireGlow() {
        fireAmount = 0
        withAnimation(.easeInOut(duration: 0.75).repeatForever(autoreverses: true)) {
            fireAmount = 20
        }
    }
    
}


