import SwiftUI
import AVKit

struct AutoReverseVideoView: UIViewControllerRepresentable {
    let videoName: String
    let videoExtension: String
    
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let playerViewController = AVPlayerViewController()
        let player = AVPlayer()
        
        if let url = Bundle.main.url(forResource: videoName, withExtension: videoExtension) {
            let playerItem = AVPlayerItem(url: url)
            player.replaceCurrentItem(with: playerItem)
        }
        
        player.isMuted = true
        playerViewController.player = player
        playerViewController.showsPlaybackControls = false
        
        context.coordinator.setupAutoReverse(player: player)
        
        return playerViewController
    }
    
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }
    
    class Coordinator {
        private var player: AVPlayer?
        private var isReversing = false
        
        func setupAutoReverse(player: AVPlayer) {
            self.player = player
            player.play()
            
            NotificationCenter.default.addObserver(
                forName: .AVPlayerItemDidPlayToEndTime,
                object: player.currentItem,
                queue: .main
            ) { _ in
                self.reversePlayback()
            }
        }
        
        func reversePlayback() {
            guard let player = player, let item = player.currentItem else { return }
            
            if isReversing {
                player.seek(to: .zero)
                player.rate = 1.0
            } else {
                player.seek(to: item.duration)
                player.rate = -1.0
            }
            
            isReversing.toggle()
        }
    }
}


