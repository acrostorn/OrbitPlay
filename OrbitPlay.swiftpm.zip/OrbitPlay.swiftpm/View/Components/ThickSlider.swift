import SwiftUI

struct TickSlider: View {
    @State private var value: CGFloat = 1.0
    @State private var offset: CGFloat = 0.0
    let minValue: CGFloat = 0.5
    let maxValue: CGFloat = 5.0
    let step: CGFloat = 0.1
    let majorTickInterval: CGFloat = 1.0
    let minorTickInterval: CGFloat = 0.1
    
    var body: some View {
        VStack {
            GeometryReader { geometry in
                ZStack(alignment: .bottom) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 0) {
                            Path { path in
                                let width = geometry.size.width /** 2*/
                                let totalSteps = (maxValue - minValue) / minorTickInterval
                                let stepWidth = width / totalSteps
                                
                                for i in 0...Int(totalSteps) {
                                    let x = CGFloat(i) * stepWidth
                                    let tickValue = minValue + CGFloat(i) * minorTickInterval
                                    
                                    let isMajor = abs(tickValue.remainder(dividingBy: majorTickInterval)) < 0.01
                                    let tickHeight: CGFloat = isMajor ? 20 : 10
                                    let tickWidth: CGFloat = isMajor ? 4 : 2
                                    path.addRoundedRect(in: CGRect(x: x, y: 0, width: tickWidth, height: tickHeight), cornerSize: CGSize(width: tickWidth / 2, height: tickWidth / 2))
                                }
                            }
                            .stroke(Color.white, lineWidth: 2)
                            .frame(width: geometry.size.width /** 2*/, height: 30)
                        }
                        .offset(x: offset)
                    }
                    .contentShape(Rectangle())
                    .gesture(DragGesture()
                        .onChanged { gesture in
                            let newOffset = offset + gesture.translation.width
                            let maxOffset = geometry.size.width / 2
                            let minOffset = -geometry.size.width * 1.5
                            offset = max(min(newOffset, maxOffset), minOffset)
                            
                            let width = geometry.size.width * 2
                            let normalized = (-offset + geometry.size.width / 2) / width
                            let newValue = minValue + normalized * (maxValue - minValue)
                            value = round(newValue / step) * step
                        }
                    )
                    
                    Path { path in
                        let centerX = geometry.size.width / 2
                        path.addRoundedRect(in: CGRect(x: centerX - 2, y: 0, width: 4, height: 25), cornerSize: CGSize(width: 2, height: 2))
                    }
                    .stroke(Color.blue, lineWidth: 3)
                }
                .onAppear {
                    let width = geometry.size.width /** 2*/
                    let totalSteps = (maxValue - minValue) / minorTickInterval
                    let _ = width / totalSteps
                    let initialOffset = (1.0 - minValue) / (maxValue - minValue) * width - width / 2
                    offset = initialOffset
                }
            }
            .frame(height: 30)
            
            Text(String(format: "%.1f", value))
                .font(.title)
                .foregroundStyle(.white)
        }
        .padding()
    }
}
