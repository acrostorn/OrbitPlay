import SwiftUI

struct SatelliteIntroSheet: View {
    @Binding var showNavi: Bool
    @State private var glowAmount: CGFloat = 0.0
    
    var body: some View {
        VStack {
            Text("Mission Overview")
                .foregroundStyle(.white)
                .font(.title)
                .bold()
                .padding(.bottom, 20)
            
            HStack {
                Image(systemName: "camera.fill")
                    .font(.largeTitle)
                    .padding(.trailing)
                    .foregroundStyle(.blue)
                    
                VStack(alignment: .leading) {
                    Text("Observation & Data Collection")
                        .foregroundStyle(.white)
                        .bold()
                    Text("Your satellite sends live updates from cameras and sensors as it orbits through space. In just 24 seconds, you'll experience a full day of satellite operations.")
                        .foregroundStyle(.gray)
                        .frame(maxWidth: .infinity)
                }
                .offset(x: -17)
            }
            .padding(.bottom)
            
            HStack {
                Image(systemName: "lightbulb.fill")
                    .font(.largeTitle)
                    .padding(.trailing)
                    .foregroundStyle(.blue)
                    .offset(x: 10)
                
                VStack(alignment: .leading) {
                    Text("Data Analysis & Investigation")
                        .foregroundStyle(.white)
                        .bold()
                    Text("Take on the role of a space detective. Use the data you've gathered to learn about your satellite's performance. Carefully review sensor readings and communications data to find clues about how your satellite is operating. ")
                        .foregroundStyle(.gray)
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.bottom)
            
            Button {
                showNavi.toggle()
            } label: {
                Text("OK")
                    .bold()
                    .foregroundStyle(.white)
                    .padding()
                    .padding(.horizontal)
                    .background(RoundedRectangle(cornerRadius: 15).fill(Color.blue))
            }
        }
        .frame(width: 500)
        .padding(25)
        .background(
            RoundedRectangle(cornerRadius: 25)
                .fill(LinearGradient(
                        gradient: Gradient(colors: [Color.blue, Color.cyan, Color.teal, Color.blue]),
                        startPoint: .leading,
                        endPoint: .trailing
                      )
                 )
                .shadow(color: Color.blue.opacity(0.6), radius: glowAmount)
                .padding(150)
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.thinMaterial)
                        .environment(\.colorScheme, .dark)
                )
        )
        .onAppear {
            animateGlow()
        }
    }

    
    private func animateGlow() {
        withAnimation(.easeInOut(duration: 1).repeatForever(autoreverses: true)) {
            glowAmount = 40
        }
    }
}
