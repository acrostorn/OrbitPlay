import SwiftUI

struct TickData: Equatable {
    let id: Int
    let midX: CGFloat
}

struct TickPreferenceKey: PreferenceKey {
    typealias Value = [TickData]
    static var defaultValue: [TickData] = []
    static func reduce(value: inout [TickData], nextValue: () -> [TickData]) {
        value.append(contentsOf: nextValue())
    }
}

struct CustomSlider: View {
    let width: Int
    private let minValue = 0.5
    private let maxValue = 5.0
    private let scaleCount: Int = 46
    @Binding var scale: Float
    private let tickInterval: CGFloat = 25.0
    
    var body: some View {
        GeometryReader { parentGeo in
            ZStack {
                ScrollViewReader { proxy in
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 0) {
                            Color.clear.frame(width: leftSpacerWidth)
                            ForEach(0..<scaleCount, id: \.self) { i in
                                VStack(spacing: 4) {
                                    Rectangle()
                                        .fill(Color.white)
                                        .frame(width: i % 5 == 0 ? 6 : 4, height: i % 5 == 0 ? 25 : 10)
                                        .cornerRadius(i % 5 == 0 ? 3 : 2)
                                        .frame(width: tickInterval, height: i % 5 == 0 ? 25 : 10)
                                        .background(
                                            GeometryReader { geo in
                                                Color.clear
                                                    .preference(key: TickPreferenceKey.self, value: [TickData(id: i, midX: geo.frame(in: .global).midX)])
                                            }
                                        )
                                    if i % 5 == 0 {
                                        Text(getScaleString(i))
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(width: tickInterval)
                                .id(i)
                            }
                            Color.clear.frame(width: leftSpacerWidth)
                        }
                    }
                    .onAppear {
                        let initialId = Int(round((Double(scale) - minValue) / 0.1))
                        let clampedId = min(max(initialId, 0), scaleCount - 1)
                        proxy.scrollTo(clampedId, anchor: .center)
                    }
                    .onPreferenceChange(TickPreferenceKey.self) { tickData in
                        let sortedTicks = tickData.sorted { $0.id < $1.id }
                        guard let firstTick = sortedTicks.first, let lastTick = sortedTicks.last else { return }
                        let parentCenter = parentGeo.frame(in: .global).midX
                        let totalDistance = lastTick.midX - firstTick.midX
                        let fraction = min(max((parentCenter - firstTick.midX) / totalDistance, 0), 1)
                        let newScale = minValue + (maxValue - minValue) * Double(fraction)
                        scale = Float(newScale)
                    }
                }
                RoundedRectangle(cornerRadius: 3)
                    .fill(Color.blue)
                    .frame(width: 6, height: 30)
                    .shadow(color: .blue, radius: 8)
                    .position(x: CGFloat(width) / 2, y: parentGeo.size.height / 2)
                    .offset(y: -15)
            }
        }
        .frame(width: CGFloat(width), height: 50)
    }
    
    var leftSpacerWidth: CGFloat {
        return CGFloat(width) / 2 - tickInterval / 2
    }
    
    private func getScaleString(_ num: Int) -> String {
        let value = 0.5 + Double(num) * 0.1
        return String(format: "%.1f", value)
    }
}
