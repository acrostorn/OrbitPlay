import SwiftUI

struct TypeWriterTextView: View {
     let text: String
     let speed: TimeInterval
     @Binding var isStart: Bool
     @Binding var isAnimating: Bool
     @Binding var launchingFlag: Bool
     @State private var textArray: String = ""
     @EnvironmentObject private var appState: AppState
    
    @State private var animate = false
    
    var body: some View {
        HStack {
            if text == "Excellent work! Everything is set. The moment has arrived—let’s launch and begin your mission!" {
                Text("Launch")
                    .foregroundStyle(.clear)
                    .font(.title2)
                    .bold()
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .fill(Color.clear)
                    )
                    .padding(.leading, 60)
            }
                
            Spacer()
            Text(textArray)
                .foregroundStyle(Color.white)
                .bold()
                .onChange(of: text) {
                    textArray = ""
                    isStart = true
                }
                .onChange(of: isStart) {
                    if isStart {
                        startAnimation()
                    }
                }  
                .multilineTextAlignment(launchingFlag ? .center : .leading)
            
            Spacer()
            
            if text == "Excellent work! Everything is set. The moment has arrived—let’s launch and begin your mission!" || text == "Mission complete! You can continue optimizing your satellite and orbit to modify simulation outcomes. Until next time!" {
                Button(action: {
                    if !isStart && isAnimating {
                        withAnimation(.spring(duration: 0.5)) {
                            appState.appSequence = .launchingNow
                            isAnimating.toggle()
                            launchingFlag = true
                        }
                    }
                }) {
                    Text("LAUNCH")
                        .font(.title3)
                        .bold()
                        .foregroundStyle(
                            isStart ? 
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.grayBlack, Color.grayBlack]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            :
                             LinearGradient(
                                gradient: Gradient(colors: [Color.red, Color.orange, Color.yellow, Color.red]),
                                    startPoint: animate ? .trailing : .leading,
                                    endPoint: animate ? .leading : .trailing
                               )
                        )
                        .shadow(color: isStart ? .clear : .red, radius: animate ? 8 : 2) 
                        .offset(y: animate ? -1 : 1) 
                        .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: animate)
                        .padding()
                        .background(
                            VStack {
                                if isStart {
                                    RoundedRectangle(cornerRadius: 5)
                                        .fill(Color.white.opacity(0.5))
                                } else {
                                    RoundedRectangle(cornerRadius: 5)
                                        .fill(.thickMaterial)
                                        .environment(\.colorScheme, .dark)    
                                } 
                            }
                        )
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
                .onAppear {
                    withAnimation(.linear(duration: 2).repeatForever(autoreverses: true)) {
                        animate.toggle()
                    }
                }
                .padding(.trailing, 40)
            }
        }
    }
    
    private func startAnimation() {
        DispatchQueue.global().async {
            let _ = text.map {
                Thread.sleep(forTimeInterval: speed)
                textArray += $0.description
            }
            DispatchQueue.main.async {
                isStart = false
            }
        }
    }
}
