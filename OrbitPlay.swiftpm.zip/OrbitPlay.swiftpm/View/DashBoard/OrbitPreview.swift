import SwiftUI
import SceneKit

struct OrbitPreview: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var userParams: UserParams
    @State private var scene = SCNScene()
    @State private var earthNode = SCNNode()
    @State private var ellipseNode = SCNNode()
    
    var body: some View {
        SceneView(
            scene: scene,
            options: [.autoenablesDefaultLighting]
        )
        .onAppear {
            scene = SCNScene()
            scene.background.contents = UIColor(Color.middleBlack)
            
            updateEarthNode()
            
            let cameraNode = SCNNode()
            cameraNode.camera = SCNCamera()
            cameraNode.position = SCNVector3(x: 0, y: 1, z: 6)
            cameraNode.look(at: SCNVector3(0,0,0))
            scene.rootNode.addChildNode(cameraNode)
            
            moveCamera()
        }
        .onChange(of: userParams.values) {
            if ![.naviToSatellite, .welcomeToSatellite, .naviToOrbit].contains(appState.appSequence) {
                updateEllipseNode()
                updateEarthNode()
            }
        }
    }
    
    private func moveCamera() {
        
        guard let cameraNode = scene.rootNode.childNodes.first(where: { $0.camera != nil}) else { return }
        
        let lookAtConstraint = SCNLookAtConstraint(target: createLookAtTarget())
        lookAtConstraint.isGimbalLockEnabled = true
        
        cameraNode.constraints = [lookAtConstraint]
        
        let moveAction = SCNAction.move(to: SCNVector3(0,3,10), duration: 1)
        moveAction.timingMode = .easeInEaseOut
        
        cameraNode.runAction(moveAction)
    }
    
    private func createLookAtTarget() -> SCNNode {
        let targetNode = SCNNode()
        targetNode.position = SCNVector3(0,0,0)
        scene.rootNode.addChildNode(targetNode)
        return targetNode
    }
    
    func updateEarthNode() {
        earthNode.removeFromParentNode()
        
        let newNode = createEarthNode()
        scene.rootNode.addChildNode(newNode)
        
        earthNode = newNode
    }
    
    func createEarthNode() -> SCNNode {
        var node = SCNNode()
        
        let earth = SCNSphere(radius: 0.95)
        let material = SCNMaterial()
        if [.naviToSatellite, .welcomeToSatellite, .naviToOrbit].contains(appState.appSequence) {
            earth.segmentCount = 24
            material.fillMode = .lines
            material.diffuse.contents = UIColor.gray
            material.transparency = 0.5
            material.transparencyMode = .aOne
            material.fillMode = .lines
        } else {
            material.diffuse.contents = UIImage(named: "earth_texture_map_with_clouds___1k___by_colourness_dg3wwrg-pre")
        }
        earth.materials = [material]
        node = SCNNode(geometry: earth)
        node.position = SCNVector3(0,0,0)
        
        return node
    }
    
    func updateEllipseNode() {
        ellipseNode.removeFromParentNode()
        
        let newEllipseNode = createEllipseNode()
        scene.rootNode.addChildNode(newEllipseNode)
        
        ellipseNode = newEllipseNode
    }
    
    func createEllipseNode() -> SCNNode {
        var a: Float = userParams.a/6400
        if a > 30000/6400 {
            a = 30000/6400
        }
        let b: Float = OrbitSceneView().calculateShortRadius(a: a, e: userParams.e)
        let i: Float = userParams.i
        let Ω: Float = userParams.Ω
        let segments = 100
        var vertices = [SCNVector3]()
        
        let width: Float = a 
        let height: Float = b
        
        for i in 0...segments {
            let angle = Float(i) * (2.0 * Float.pi / Float(segments))
            
            let x = width * cos(angle)
            let z = height * sin(angle)
            
            vertices.append(SCNVector3(x, 0, z))
        }
        
        let vertexSource = SCNGeometrySource(vertices: vertices)
        
        var indices = [Int32]()
        for i in 0..<segments {
            indices.append(Int32(i))
            indices.append(Int32(i + 1))
        }
        
        indices.append(Int32(segments))
        indices.append(0)
        
        let element = SCNGeometryElement(indices: indices, primitiveType: .line)
        
        let geometry = SCNGeometry(sources: [vertexSource], elements: [element])
        let material = SCNMaterial()
        material.diffuse.contents = UIColor(Color.white)
        material.emission.contents = UIColor(Color.white)
        geometry.materials = [material]
        
        let tmpNode = SCNNode(geometry: geometry)
        
        let eulerXAngle = i * Float.pi / 180
        let eulerYAngle = -1 * .pi/2 + Ω * Float.pi / 180
        tmpNode.eulerAngles = SCNVector3(x: eulerXAngle, y: eulerYAngle, z: 0)
        
        return tmpNode
    }
}
