import SwiftUI

struct ThankYouView: View {
    @Binding var showSheet: Bool
    @State private var showCredits = false
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        VStack {
            if !showCredits {
                VStack {
                    Text("Thank You for Playing!!")
                        .font(.largeTitle)
                        .bold()
                    
                    SatellitePreview(isThankYou: true)
                        .frame(width: 440, height: 150)
                        .padding(.bottom)
                    
                    Text("I hope you had fun running your own mission!\nIf this was your first step into space engineering, then it’s one small step for you, and one giant leap into the universe of possibilities! 🧑‍🚀🌕\nReady to explore further? Tap 'Continue' to customize your satellite and orbit.\nThank you for playing this playground!")
                        .padding(.bottom, 30)
                    
                    Button("Continue") {
                        appState.appSequence = .continuePlaying
                        showSheet.toggle()
                    }
                    .bold()
                    .font(.title3)
                    .padding(.horizontal)
                    .padding()
                    .foregroundStyle(.white)
                    .background(RoundedRectangle(cornerRadius: 15).fill(.black))
                    .padding(.bottom)
                }
            }
            
            if showCredits {
                ScrollView {
                    CreditsView()
                }
            }
            
            Button(!showCredits ? "Credits" : "Back") {
                withAnimation {
                    showCredits.toggle()
                }
            }
            .foregroundStyle(.blue)
        }
        .foregroundStyle(Color.black)
        .padding(30)
        .frame(width: 500)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.white)
        )
    }
}
