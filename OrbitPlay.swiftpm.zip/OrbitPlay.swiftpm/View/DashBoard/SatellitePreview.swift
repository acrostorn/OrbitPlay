import SwiftUI
import SceneKit

struct SatellitePreview: View {
    @State private var scene = SCNScene()
    @EnvironmentObject var userComponents: UserComponents
    
    var isThankYou = false
    
    var body: some View {
        SceneView(
            scene: scene,
            options: [.autoenablesDefaultLighting]
        )
        .onAppear {
            scene = SCNScene()
            scene.background.contents = isThankYou ? UIColor.white : UIColor(Color.middleBlack)
            
            let satelliteNode = createSatelliteNode()
            satelliteNode.position = SCNVector3(0,0,0)
            scene.rootNode.addChildNode(satelliteNode)
            
            let cameraNode = SCNNode()
            cameraNode.camera = SCNCamera()
            cameraNode.position = SCNVector3(x: 0, y: 1, z:6)
            cameraNode.look(at: SCNVector3(0,0,0))
            scene.rootNode.addChildNode(cameraNode)
            
            moveCamera()
        }
    }
    
    private func createSatelliteNode() -> SCNNode {
        let parentNode = SCNNode()
        
        //body
        let bodyNode = getModel(userComponents.bodyMaterial)
        bodyNode.position = SCNVector3(x:0, y:0, z:0)
        parentNode.addChildNode(bodyNode)
        
        //solarPanel
        let panelNodeL = getModel(userComponents.solarPanel)
        let panelNodeR = getModel(userComponents.solarPanel)
        panelNodeR.eulerAngles = SCNVector3(0, Float.pi, 0)
        panelNodeR.position = SCNVector3(-0.5, 0, 0)
        panelNodeL.position = SCNVector3(0.5, 0, 0)
        parentNode.addChildNode(panelNodeL)
        parentNode.addChildNode(panelNodeR)
        
        return parentNode
    }
    
    private func moveCamera() {
        guard let cameraNode = scene.rootNode.childNodes.first(where: { $0.camera != nil }) else { return }
        
        let lookAtConstraint = SCNLookAtConstraint(target: createLookAtTarget())
        lookAtConstraint.isGimbalLockEnabled = true 
        
        cameraNode.constraints = [lookAtConstraint]
        
        let moveAction = SCNAction.move(to: isThankYou ? SCNVector3(0.5, 1, 4) : SCNVector3(2,3,12), duration: 1)
        moveAction.timingMode = .easeInEaseOut
        
        cameraNode.runAction(moveAction)
    }
    
    private func createLookAtTarget() -> SCNNode {
        let targetNode = SCNNode()
        targetNode.position = SCNVector3(0, 0, 0)
        scene.rootNode.addChildNode(targetNode)
        return targetNode
    }

}
