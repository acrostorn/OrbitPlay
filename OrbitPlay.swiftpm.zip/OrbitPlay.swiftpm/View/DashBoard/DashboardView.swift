//
//  DashboardView.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/26.
//

import SwiftUI

struct DashboardView: View {
    @EnvironmentObject var appState: AppState
    @State private var isAnimating = false
    private let screenSize = UIScreen.main.bounds
    @State var isNaviCircle = true
    @State var isStart = false
    @State private var isFirstFinish = true
    @State private var showThankYou = false
    @State private var bubblePaddingCount: CGFloat = 50
    @State private var launchingFlag = false
    @State private var showlaunchText = false
    @State private var isRecording = false
    
    var body: some View {
        ZStack {
            VStack {
                if appState.appSequence == .tapMe {
                    TypeWriterTextView(
                        text: "TAP ME",
                        speed: 0.1,
                        isStart: $isStart,
                        isAnimating: $isAnimating,
                        launchingFlag: $launchingFlag
                    )  
                    .padding(.bottom)
                }
                
                NavigationBubble(isStart: $isStart, isAnimating: $isAnimating, launchingFlag: $launchingFlag, isCircle: $isNaviCircle)
                    .padding(.horizontal, bubblePaddingCount)
                    .padding(.bottom)
                
                if !isAnimating {
                    if appState.appSequence != .tapMe {
                        navigationButtons()
                            .padding(appState.appSequence == .launchingNow ? 0 : 15)
                            .onAppear {
                                if appState.appSequence == .launchingNow {
                                    isNaviCircle.toggle()
                                }
                            }
                    }
                }
                
                if isAnimating {
                    VStack {
                        HStack {
                            satellitePreviewComponent()
                                .transition(.move(edge: .leading))
                                .padding(.trailing)
                            orbitPreviewComponent()
                                .transition(.move(edge: .trailing))
                        }
                        .padding(.bottom)
                    }
                    .transition(.move(edge: .bottom))
                }
            }
            .padding()
            
            if showThankYou {
                Rectangle().fill(.black.opacity(0.75)).frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()
                
                ThankYouView(showSheet: $showThankYou)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.darkBlack)
        .onChange(of: appState.appSequence) {
            if appState.appSequence == .tapMe {
                isStart.toggle()
            } else if appState.appSequence == .finishAR {
                if isFirstFinish {
                    isFirstFinish.toggle()
                    appState.appSequence = .thankYou
                    showThankYou.toggle()
                } else {
                    appState.appSequence = .continuePlaying
                }
            }
        }
        .onChange(of: isAnimating) {
            withAnimation {
                if isAnimating {
                    bubblePaddingCount = 0
                } else {
                    bubblePaddingCount = 50
                }
            }
        }
    }
    
    
    @State private var navigationButtonText = "NEXT"
    @ViewBuilder
    private func navigationButtons() -> some View {
        if appState.appSequence == .goAR {
            if isStart {
                Button("OK") {}
                    .foregroundStyle(Color.grayBlack)
                    .font(.title2)
                    .fontWeight(.heavy)
            } else {
                NavigationLink("OK") {
                    ARView()
                        .navigationBarBackButtonHidden()
                        .onAppear {
                            navigationButtonText = ""
                            appState.appSequence = .startAR
                            appState.arSequence = .arNotStarted
                            isAnimating.toggle()
                        }
                }
                .foregroundStyle(isStart ? Color.grayBlack : .white)
                .font(.title2)
                .fontWeight(.heavy)
            }
        } else {
            Button(navigationButtonText) {
                if isStart {
                    return
                } 
                switch appState.appSequence {
                case .hello :
                    appState.appSequence = .goDashBoard
                case .goDashBoard :
                    appState.appSequence = .naviToSatellite
                    withAnimation(.spring(duration: 0.5)) {
                        isAnimating.toggle()
                    }          
                case .launchSucceed:
                    appState.appSequence = .goAR
                default:
                    print("そんなはずなくね")
                }    
            }
            .foregroundStyle(isStart ? Color.grayBlack : Color.white)
            .font(.title2)
            .fontWeight(.heavy)
            .onChange(of: appState.appSequence) {
                switch appState.appSequence {
                case .hello :
                    navigationButtonText = "NEXT"
                case .goDashBoard :
                    navigationButtonText = "BEGIN"
                case .launchingNow:
                    navigationButtonText = ""
                case .launchSucceed :
                    navigationButtonText = "NEXT"
                case .goAR:
                    navigationButtonText = ""
                case .continuePlaying:
                    navigationButtonText = ""
                default:
                    navigationButtonText = ""
                }  
            }
        }
        
        
    }
    
}

fileprivate struct satellitePreviewComponent: View {
    @EnvironmentObject private var appState: AppState
    @State private var statusFlag = false
    @State private var glowAmount: CGFloat = 0.0
    
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Satellite")
                            .font(.largeTitle)
                            .foregroundStyle(.white)
                        HStack {
                            Text("⚫︎")
                                .foregroundStyle(statusFlag ? .green : .red)
                            Text(statusFlag ? "satellite is ready to launch" : "satellite is incomplete")
                                .foregroundStyle(Color.grayBlack)
                        }
                    }
                    .bold()
                    Spacer()
                }
                .padding(.bottom, 7)
                
                Spacer()
                
                SatellitePreview()
                
                Spacer()
                
                NavigationLink {
                    BuildingView()
                } label: {
                    Text("Assemble Satellite").bold().foregroundStyle(appState.appSequence == .naviToSatellite ? Color.white : .black)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            ZStack {
                                if appState.appSequence == .naviToSatellite {
                                    RoundedRectangle(cornerRadius: 15)
                                        .fill(LinearGradient(
                                            gradient: Gradient(colors: [Color.blue, Color.cyan, Color.teal, Color.blue]),
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        )
                                        )
                                        .shadow(color: Color.blue.opacity(0.6), radius: glowAmount)
                                } else {
                                    RoundedRectangle(cornerRadius: 15)
                                        .fill(Color.white)
                                }
                                
                                if appState.appSequence == .naviToSatellite {
                                    RoundedRectangle(cornerRadius: 15)
                                        .fill(.thinMaterial)
                                        .environment(\.colorScheme, .dark)
                                }
                            }
                        )
                }
            }
            .frame(maxHeight: .infinity)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 25).fill(Color.middleBlack)
            )
        }
        .onChange(of: appState.appSequence) {
            if appState.appSequence == .naviToOrbit || appState.appSequence == .thankYou || appState.appSequence == .continuePlaying{
                statusFlag = true
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                glowAmount = 40
                print("repeat")
            }
        }
    }
}

fileprivate struct orbitPreviewComponent: View {
    @EnvironmentObject private var appState: AppState
    @State private var statusFlag = false
    @State private var glowAmount: CGFloat = 0.0
    @State private var buttonTextColor: Color = .white
    
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Orbit")
                            .font(.largeTitle)
                            .foregroundStyle(.white)
                        HStack {
                            Text("⚫︎").foregroundStyle(statusFlag ? .green : .red)
                            Text(statusFlag ? "orbit is ready to launch" : "orbit is incomplete").foregroundStyle(Color.grayBlack)
                        }
                    }
                    .bold()
                    Spacer()
                }
                
                Spacer()
                
                OrbitPreview()
                
                Spacer()
                
                if appState.appSequence == .naviToSatellite {
                    Text("Design Orbit").bold().foregroundStyle(buttonTextColor)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.grayBlack)
                        )
                } else {
                    NavigationLink {
                        if appState.appSequence != .naviToSatellite {
                            DesignOrbitView()
                        } 
                        
                    } label: {
                        Text("Design Orbit").bold().foregroundStyle(buttonTextColor)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                ZStack {
                                    if appState.appSequence == .naviToOrbit {
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(LinearGradient(
                                                gradient: Gradient(colors: [Color.blue, Color.cyan, Color.teal, Color.blue]),
                                                startPoint: .leading,
                                                endPoint: .trailing
                                            )
                                            )
                                            .shadow(color: Color.blue.opacity(0.6), radius: glowAmount)
                                    } else if appState.appSequence == .naviToSatellite {
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(Color.grayBlack)
                                    } else {
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(Color.white)
                                    }
                                    
                                    if appState.appSequence == .naviToOrbit {
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(.thinMaterial)
                                            .environment(\.colorScheme, .dark)
                                    }
                                }
                            )
                    } 
                }
            }
            .frame(maxHeight: .infinity)
            .padding()
            .background(RoundedRectangle(cornerRadius: 25).fill(Color.middleBlack))
        }
        .onChange(of: appState.appSequence) {
            if appState.appSequence == .goForLaunch || appState.appSequence == .thankYou || appState.appSequence == .continuePlaying {
                statusFlag = true
                buttonTextColor = .darkBlack
            }
        }
        .onAppear {
            if appState.appSequence == .naviToOrbit {
                withAnimation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                    glowAmount = 40
                    print("repeat")
                }
            }
        }
    }
}

fileprivate struct launchButtonComponent: View {
    var body: some View {
        NavigationStack {
            NavigationLink {
                ARView()
            } label: {
                RoundedRectangle(cornerRadius: 15).fill(Color.green)
            }
        }
    }
}

#Preview {
    DashboardView()
}
