import SwiftUI

struct CreditsView: View {
    var body: some View {
            VStack(alignment: .leading, spacing: 10) {
                
                Text("Credits")
                    .font(.largeTitle)
                    .bold()
                
                SectionView(title: "Images", items: [
                    ("NASA Scientific Visualization Studio", "https://svs.gsfc.nasa.gov"),
                    ("NASA Visible Earth", "https://visibleearth.nasa.gov"),
                    ("Wikipedia Commons", "Various images from Wikimedia Commons are used in this project. Since each image has a different license, detailed license information is provided within the Playground.")
                ])
                
                SectionView(title: "Information Sources", items: [
                    ("JAXA", "https://www.jaxa.jp"),
                    ("NASA", "https://www.nasa.gov"),
                    ("ISAS", "https://www.isas.jaxa.jp"),
                    ("Oukado.org", "https://www.oukado.org"),
                    ("Fabriclore", "https://www.fabriclore.com"),
                    ("NEED", "https://www.need.org"),
                    ("ESA", "https://www.esa.int")
                ])
                
                SectionView(title: "Frameworks Used", items: [
                    ("SwiftUI", ""),
                    ("SceneKit", ""),
                    ("ARKit", ""),
                    ("Charts", ""),
                    ("AVKit", "")
                ])
                
                SectionView(title: "External Tools Used", items: [
                    ("Canva", "Used for app icon design"),
                    ("ChatGPT", "Used for English translation and researching Framework usage")
                ])
                
                Text("This project was developed with Swift Playground to provide an interactive and educational experience about satellite orbits and space exploration. Thank you for exploring OrbitPlay!")
                    .font(.footnote)
                    .foregroundStyle(.black)
                    .padding(.top, 10)
            }
            .padding()
        }
}

struct SectionView: View {
    let title: String
    let items: [(String, String)]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.title2)
                .foregroundStyle(.black)
                .bold()
                .padding(.vertical, 10)
            
            ForEach(items, id: \.0) { item in
                VStack(alignment: .leading) {
                    Text(item.0)
                        .font(.body)
                        .bold()
                        .foregroundStyle(.black)
                    if !item.1.isEmpty {
                        Text(item.1)
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }
                }
                .padding(.bottom, 2)
            }
        }
    }
}
