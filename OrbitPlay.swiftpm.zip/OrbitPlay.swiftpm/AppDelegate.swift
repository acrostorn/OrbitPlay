//
//  AppDelegate.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/09.
//

import SwiftUI

@main
struct OrbitPlay: App {
    @StateObject private var userParams = UserParams()
    @StateObject private var userComponents = UserComponents()
    @StateObject private var appState = AppState()
    @StateObject private var imageHolder = ImageHolder()
    
    @State private var showLandscape = false
    let timer = Timer.publish(every: 1.5, on: .main, in: .common).autoconnect()
    
    var body: some Scene {
        WindowGroup {
            GeometryReader { geo in
                let isLandscape = geo.size.width > geo.size.height
                ZStack {
                    ContentView()
                        .environmentObject(userParams)
                        .environmentObject(userComponents)
                        .environmentObject(appState)
                        .environmentObject(imageHolder)
                    
                    if !isLandscape {
                        Color.black.opacity(0.9)
                            .overlay(
                                VStack {
                                    Text("Please rotate your iPad to landscape mode.")
                                        .font(.largeTitle)
                                        .bold()
                                    
                                    ZStack {
                                        Image(systemName: "ipad.gen2.landscape")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: 200, height: 200)
                                            .opacity(showLandscape ? 0 : 1)
                                        
                                        Image(systemName: "ipad.gen2")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: 200, height: 200)
                                            .opacity(showLandscape ? 1 : 0)
                                    }
                                    .animation(.easeInOut(duration: 1.0), value: showLandscape)
                                } 
                                .foregroundStyle(.white)
                            )
                            .ignoresSafeArea()
                    }
                }
                .onReceive(timer) { _ in
                    showLandscape.toggle()
                }
            }
        }
    }
}
