import SwiftUI

extension Color {
    static let darkBlack = Color(red: 10 / 255.0, green: 10 / 255.0, blue: 10 / 255.0)
    static let middleBlack = Color(red: 28 / 255.0, green: 28 / 255.0, blue: 28 / 255.0)
    static let lightBlack = Color(red: 43 / 255.0, green: 43 / 255.0, blue: 43 / 255.0)
    static let grayBlack = Color(red: 103 / 255.0, green: 103 / 255.0, blue: 103 / 255.0)
}
