import SwiftUI
//import UIKit

class ImageHolder: ObservableObject {
    @Published var postureImage: UIImage?
    @Published var cameraImage: UIImage?
}
