//
//  OrbitData.swift5
//  LearnEarthOrbit
//
//  Created by USER on 2024/11/20.
//

import Foundation

struct ParamIndex: Equatable, Identifiable {
    let id = UUID()
    
    let name: String
    let value: Float
    let unit: String
    let range: ClosedRange<Float>
}

class UserParams: ObservableObject {
    @Published var a: Float = 30000
    @Published var e: Float = 0
    @Published var i: Float = 0
    @Published var Ω: Float = 0
    @Published var ω: Float = 60
    @Published var ν: Float = 30
    
    @Published var infoItem: String = ""
    @Published var scrollCount: Int = 0
    
    var values: [ParamIndex] {
        return [
            ParamIndex(name: "Semi-Major Axis", value: a, unit: "km", range: 15000...45000),
            ParamIndex(name: "Inclination", value: i, unit: "°", range: 0...90),
            ParamIndex(name: "Longitude of the Ascending Node", value: Ω, unit: "°", range: 0...90),
            ParamIndex(name: "Eccentricity", value: e, unit: "", range: 0...1),
            ParamIndex(name: "Argument of Perigee", value: ω, unit: "°", range: 0...360),
            ParamIndex(name: "True Anomaly", value: ν, unit: "°", range: 0...360)
        ]
    }
}
