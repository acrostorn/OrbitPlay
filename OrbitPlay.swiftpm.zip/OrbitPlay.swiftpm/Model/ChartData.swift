import SwiftUI

struct ChartData: Identifiable {
    let id = UUID()
    let x: Int
    let y: Float
}

struct MapPlotData: Identifiable, Hashable {
    let id = UUID()
    let lon: Float
    let lat: Float
    let segmentID: Int
}

struct PostureData: Identifiable {
    let id = UUID()
    let x: Float
    let y: Float
    let z: Float
}

struct SensorData: Identifiable {
    let id = UUID()
    let internalValue: Float
    let externalValue: Float
}
