import SwiftUI

enum AppSequence {
    case appStart
    case tapMe
    case hello
    case goDashBoard
    case naviToSatellite
    case welcomeToSatellite
    case naviToOrbit
    case welcomeToOrbit
    case goForLaunch
    case launchingNow
    case launchSucceed
    case goAR
    case startAR
    case finishAR
    case thankYou
    case continuePlaying
    
    
    
//    
//    case preparationStart
//    case satelliteReady
//    case orbitReady
//    case missionStart
}

enum ARSequence {
    case arNotStarted
    case contemplatingPlacement
    case objectPlaced
    case showIntroSheet
    case missionStart
    case missionFailed
    case missionSucceed
    //case placingObject
    //case interacting
    //completed
}

class AppState: ObservableObject {
    @Published var appSequence: AppSequence = .appStart
    @Published var arSequence: ARSequence = .arNotStarted
}
