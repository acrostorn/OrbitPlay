import SwiftUI
import SceneKit

func getPlateNode(material: SCNMaterial, width: Float, height: Float, eulerAngles: SCNVector3, position: SCNVector3) -> SCNNode {
    let board = SCNBox(width: CGFloat(width), height: CGFloat(height), length: 0.025, chamferRadius: 0)
    board.materials = [material]
    let boardNode = SCNNode(geometry: board)
    boardNode.eulerAngles = eulerAngles
    boardNode.position = position
    
    return boardNode
}

func getCameraNode(position: SCNVector3) -> SCNNode {
    let parentNode = SCNNode()
    
    let frame = SCNTube(innerRadius: 0.2, outerRadius: 0.25, height: 0.2)
    frame.firstMaterial?.diffuse.contents = UIColor.black 
    let frameNode = SCNNode(geometry: frame)
    parentNode.addChildNode(frameNode)
    
    let cameraLight = SCNCylinder(radius: 0.2, height: 0.05)
    let cameraLightMaterial = SCNMaterial()
    cameraLightMaterial.diffuse.contents = UIColor.red
    cameraLightMaterial.emission.contents = UIColor.red
    cameraLightMaterial.emission.intensity = 0.1
    cameraLight.materials = [cameraLightMaterial]
    let cameraLightNode = SCNNode(geometry: cameraLight)
    //    cameraLightNode.eulerAngles = SCNVector3(0,0,Float.pi)
    cameraLightNode.position = SCNVector3(0,0.03,0)
    parentNode.addChildNode(cameraLightNode)
    
    let lens = SCNCylinder(radius: 0.1, height: 0.05)
    let lensMaterial = SCNMaterial()
    lensMaterial.diffuse.contents = UIColor.black 
    lensMaterial.transparency = 0.01
    lens.materials = [lensMaterial]
    let lensNode = SCNNode(geometry: lens)
    lensNode.position = SCNVector3(0, -0.1 ,0)
    parentNode.addChildNode(lensNode)
    
    let innerFrame = SCNTube(innerRadius: 0.1, outerRadius: 0.2, height: 0.05)
    innerFrame.firstMaterial?.diffuse.contents = UIColor.lightGray
    let innerFrameNode = SCNNode(geometry: innerFrame)
    innerFrameNode.position = SCNVector3(0,-0.12,0)
    parentNode.addChildNode(innerFrameNode)
    
    let pointLight = SCNSphere(radius: 0.025)
    let lightMaterial = SCNMaterial()
    lightMaterial.emission.contents = UIColor.green
    lightMaterial.emission.intensity = 1.5
    pointLight.materials = [lightMaterial]
    let lightNode = SCNNode(geometry: pointLight)
    lightNode.position = SCNVector3(0.3,0.05,0.25)
    parentNode.addChildNode(lightNode)
    
    parentNode.position = position
    
    return parentNode
}

func getTopDevices(position: SCNVector3, material: SCNMaterial, subMaterial: SCNMaterial, inAR: Bool) -> SCNNode {
    let parentNode = SCNNode()
    
    let whiteMaterial = SCNMaterial()
    whiteMaterial.diffuse.contents = UIColor.white
    if !inAR {
        whiteMaterial.lightingModel = .physicallyBased
    }
    
    let panelMaterial = SCNMaterial()
    panelMaterial.diffuse.contents = UIColor.lightGray
    panelMaterial.metalness.contents = 1.0
    panelMaterial.roughness.contents = 0.2
    if !inAR {
        panelMaterial.lightingModel = .physicallyBased
    }
    panelMaterial.roughness.intensity = 0
    
    let box = SCNBox(width: 0.5, height: 0.05, length: 0.1, chamferRadius: 0.025)
    box.materials = [whiteMaterial]
    let boxNode = SCNNode(geometry: box)
    boxNode.position = SCNVector3(0.15,0.025,-0.35)
    parentNode.addChildNode(boxNode)
    
    let circlePlate = SCNCylinder(radius: 0.275, height: 0.05)
    circlePlate.materials = [panelMaterial]
    let circlePlateNode = SCNNode(geometry: circlePlate)
    circlePlateNode.position = SCNVector3(0.15,0.025,0.1)
    parentNode.addChildNode(circlePlateNode)
    
    let circleFrame = SCNTube(innerRadius: 0.275, outerRadius: 0.3, height: 0.025)
    circleFrame.firstMaterial?.diffuse.contents = UIColor.black
    let circleFrameNode = SCNNode(geometry: circleFrame)
    circleFrameNode.position = SCNVector3(0.15,0.0125,0.1)
    parentNode.addChildNode(circleFrameNode)
    
    let antenna = SCNCylinder(radius: 0.015, height: 0.45)
    antenna.firstMaterial?.diffuse.contents = UIColor.black
    let antennaNode = SCNNode(geometry: antenna)
    antennaNode.position = SCNVector3(-0.3,0.125,-0.35)
    parentNode.addChildNode(antennaNode)
    
    let pointLight = SCNSphere(radius: 0.025)
    let lightMaterial = SCNMaterial()
    lightMaterial.emission.contents = UIColor.red
    lightMaterial.emission.intensity = 1.5
    pointLight.materials = [lightMaterial]
    let lightNode = SCNNode(geometry: pointLight)
    lightNode.position = SCNVector3(-0.3,0,-0.25)
    parentNode.addChildNode(lightNode)
    
    let whiteBox = SCNBox(width: 0.2, height: 0.1, length: 0.2, chamferRadius: 0.025)
    whiteBox.materials = [whiteMaterial]
    let whiteBoxNode = SCNNode(geometry: whiteBox)
    whiteBoxNode.position = SCNVector3(-0.3,0,0.3)
    parentNode.addChildNode(whiteBoxNode)
    
    let longWhiteBox = SCNBox(width: 0.2, height: 0.1, length: 0.3, chamferRadius: 0.025)
    longWhiteBox.materials = [whiteMaterial]
    let longWhiteBoxNode = SCNNode(geometry: longWhiteBox)
    longWhiteBoxNode.position = SCNVector3(-0.3, -0.01, 0)
    parentNode.addChildNode(longWhiteBoxNode)
    
    parentNode.position = position
    return parentNode
}

func getSideDevices(material: SCNMaterial, subMaterial: SCNMaterial) -> SCNNode {
    let parentNode = SCNNode()
    
    let jointMaterial = SCNMaterial()
    jointMaterial.diffuse.contents = UIColor.black
    jointMaterial.metalness.contents = 0.5
    
    //lf
    parentNode.addChildNode(getPlateNode(material: jointMaterial, width: 0.15, height: 0.15, eulerAngles: SCNVector3(0,1*Float.pi/2,0), position: SCNVector3(0.51, 0, 0.25)))
    //lb
    parentNode.addChildNode(getPlateNode(material: jointMaterial, width: 0.15, height: 0.15, eulerAngles: SCNVector3(0 ,1*Float.pi/2,0), position: SCNVector3(0.51, 0, -0.25)))
    //rf
    parentNode.addChildNode(getPlateNode(material: jointMaterial, width: 0.15, height: 0.15, eulerAngles: SCNVector3(0 ,-1*Float.pi/2,0), position: SCNVector3(-0.51, 0, 0.25)))
    //rb
    parentNode.addChildNode(getPlateNode(material: jointMaterial, width: 0.15, height: 0.15, eulerAngles: SCNVector3(0 ,-1*Float.pi/2,0), position: SCNVector3(-0.51, 0, -0.25)))
    
    let wwdcSticker = SCNText(string: "WWDC25", extrusionDepth: 0.01)
    wwdcSticker.materials = [subMaterial]
    let wwdcNode = SCNNode(geometry: wwdcSticker)
    wwdcNode.scale = SCNVector3(0.005, 0.005, 0.005)
    wwdcNode.position = SCNVector3(0.501,-0.45,0.45)
    wwdcNode.eulerAngles = SCNVector3(0,Float.pi/2,0)
    parentNode.addChildNode(wwdcNode)
    
    let appSticker = SCNText(string: "OrbitPlay", extrusionDepth: 0.01)
    appSticker.materials = [subMaterial]
    let appNode = SCNNode(geometry: appSticker)
    appNode.scale = SCNVector3(0.005, 0.005, 0.005)
    appNode.position = SCNVector3(-0.501,-0.45,-0.45)
    appNode.eulerAngles = SCNVector3(0,-1*Float.pi/2,0)
    parentNode.addChildNode(appNode)
    
    return parentNode
} 

func getBackDevices(mainMaterial: SCNMaterial, subMaterial: SCNMaterial) -> SCNNode {
    let parentNode = SCNNode()
    
    let ring = SCNTube(innerRadius: 0.3, outerRadius: 0.4, height: 0.1)
    ring.materials = [mainMaterial]
    let ringNode = SCNNode(geometry: ring)
    ringNode.eulerAngles = SCNVector3(Float.pi/2,0,0)
    ringNode.position = SCNVector3(0,0,-0.55)
    
    let wideCylinder = SCNCylinder(radius: 0.3, height: 0.075)
    wideCylinder.materials = [subMaterial]
    let wideCylinderNode = SCNNode(geometry: wideCylinder)
    wideCylinderNode.eulerAngles = SCNVector3(Float.pi/2,0,0)
    wideCylinderNode.position = SCNVector3(0,0,-0.535)
    
    let cylinderFrame = SCNTube(innerRadius: 0.075, outerRadius: 0.1, height: 0.075)
    cylinderFrame.materials = [subMaterial]
    let cylinderFrameNode = SCNNode(geometry: cylinderFrame)
    cylinderFrameNode.eulerAngles = SCNVector3(Float.pi/2, 0, 0)
    cylinderFrameNode.position = SCNVector3(0,0,-0.59)
    
    let centerCylinder = SCNCylinder(radius: 0.075, height: 0.05)
    centerCylinder.firstMaterial?.diffuse.contents = UIColor.black
    let centerCylinderNode = SCNNode(geometry: centerCylinder)
    centerCylinderNode.eulerAngles = SCNVector3(Float.pi/2, 0, 0)
    centerCylinderNode.position = SCNVector3(0,0,-0.575)
    
    parentNode.addChildNode(ringNode)
    parentNode.addChildNode(wideCylinderNode)
    parentNode.addChildNode(cylinderFrameNode)
    parentNode.addChildNode(centerCylinderNode)
    return parentNode
}

func assembleBoards(mainMaterial: SCNMaterial, subMaterial: SCNMaterial, inAR: Bool) -> SCNNode {
    let parentNode = SCNNode()
    //A
    parentNode.addChildNode(getPlateNode(material: subMaterial, width: 0.35, height: 0.8, eulerAngles: SCNVector3(0,0,0), position: SCNVector3(-0.225, 0, 0.612)))
    parentNode.addChildNode(getBoxNode(width: 0.35, height: 0.8, length: 0.1, material: mainMaterial, position: SCNVector3(-0.225,0,0.55)))
    //B
    parentNode.addChildNode(getPlateNode(material: subMaterial, width: 0.35, height: 0.2, eulerAngles: SCNVector3(0,0,0), position: SCNVector3(0.225, 0.30, 0.612)))
    parentNode.addChildNode(getBoxNode(width: 0.35, height: 0.2, length: 0.1, material: mainMaterial, position: SCNVector3(0.225,0.3,0.55)))
    //C
    parentNode.addChildNode(getPlateNode(material: subMaterial, width: 0.35, height: 0.5, eulerAngles: SCNVector3(0,0,0), position: SCNVector3(0.225, -0.15, 0.612)))
    parentNode.addChildNode(getBoxNode(width: 0.35, height: 0.5, length: 0.1, material: mainMaterial, position: SCNVector3(0.225,-0.15,0.55)))
    
    //Camera
    parentNode.addChildNode(getCameraNode(position: SCNVector3(0, -0.55, 0)))
    
    //Top
    parentNode.addChildNode(getTopDevices(position: SCNVector3(0,0.5,0), material: subMaterial, subMaterial: mainMaterial, inAR: inAR))
    
    //side
    parentNode.addChildNode(getSideDevices(material: subMaterial, subMaterial: subMaterial))
    
    parentNode.addChildNode(getBackDevices(mainMaterial: mainMaterial, subMaterial: subMaterial))
    
    
    let jointA = getJoint(position: SCNVector3(0.6, 0, 0.25), inAR: inAR)
    let jointB = getJoint(position: SCNVector3(0.6, 0, -0.25), inAR: inAR)
    let jointC = getJoint(position: SCNVector3(-0.6, 0, 0.25), inAR: inAR)
    let jointD = getJoint(position: SCNVector3(-0.6, 0, -0.25), inAR: inAR)
    
    parentNode.addChildNode(jointA)
    parentNode.addChildNode(jointB)
    parentNode.addChildNode(jointC)
    parentNode.addChildNode(jointD)
    
    return parentNode
}

func getBoxNode(width: CGFloat, height: CGFloat, length: CGFloat, material: SCNMaterial, position: SCNVector3) -> SCNNode {
    let box = SCNBox(width: width, height: height, length: length, chamferRadius: 0)
    box.materials = [material]
    let boxNode = SCNNode(geometry: box)
    boxNode.position = position
    
    return boxNode
}
