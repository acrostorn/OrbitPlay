import SwiftUI
import SceneKit

func assemblePanels(inAR: Bool, style: String, materials: [SCNMaterial]) -> SCNNode {
    let parentNode = SCNNode()
    
    if style == "A" {
        let frameA = getFrameBox(width: 2.5, height: 0.1, length: 0.05, position: SCNVector3(1.45, 0,0.45), inAR: inAR)
        let frameB = getFrameBox(width: 2.5, height: 0.1, length: 0.05, position: SCNVector3(1.45, 0,-0.45), inAR: inAR)
        let frameC = getFrameBox(width: 0.05, height: 0.1, length: 0.9, position: SCNVector3(2.675, 0,0), inAR: inAR)
        let frameD = getFrameBox(width: 0.05, height: 0.1, length: 0.9, position: SCNVector3(0.225, 0,0), inAR: inAR)
        let bottom = getFrameBox(width: 2.4, height: 0.05, length: 0.9, position: SCNVector3(1.45,-0.025,0), inAR: inAR)
        let cells = getCells(inAR: inAR, materials: materials)
        
        parentNode.addChildNode(frameA)
        parentNode.addChildNode(frameB)
        parentNode.addChildNode(frameC)
        parentNode.addChildNode(frameD)
        parentNode.addChildNode(bottom)
        parentNode.addChildNode(cells)
    } else if style == "B" {
        let frameA = getFrameBox(width: 2.5, height: 0.1, length: 0.05, position: SCNVector3(1.45, 0,0.45), inAR: inAR)
        let frameB = getFrameBox(width: 2.5, height: 0.1, length: 0.05, position: SCNVector3(1.45, 0,-0.45), inAR: inAR)
        let frameC = getFrameBox(width: 0.05, height: 0.1, length: 0.9, position: SCNVector3(2.675, 0,0), inAR: inAR)
        let frameD = getFrameBox(width: 0.05, height: 0.1, length: 0.9, position: SCNVector3(0.225, 0,0), inAR: inAR)
        let bottom = getFrameBox(width: 2.4, height: 0.05, length: 0.9, position: SCNVector3(1.45,-0.025,0), inAR: inAR)
        let cells = getCells(inAR: inAR, materials: materials)
        
        parentNode.addChildNode(frameA)
        parentNode.addChildNode(frameB)
        parentNode.addChildNode(frameC)
        parentNode.addChildNode(frameD)
        parentNode.addChildNode(bottom)
        parentNode.addChildNode(cells)
    }
    
    
    return parentNode
}

func getFrameBox(width: CGFloat, height: CGFloat, length: CGFloat, position: SCNVector3, inAR: Bool) -> SCNNode {
    let box = SCNBox(width: width, height: height, length: length, chamferRadius: 0)
    let material = SCNMaterial()
    material.diffuse.contents = UIColor.lightGray
    material.metalness.contents = 1.0
    material.roughness.contents = 0.2
    if !inAR {
        material.lightingModel = .physicallyBased
    }
    material.roughness.intensity = 0
    box.materials = [material]
    let boxNode = SCNNode(geometry: box)
    boxNode.position = position
    
    return boxNode
}

func getCells(inAR: Bool, materials: [SCNMaterial]) -> SCNNode {
    let parentNode = SCNNode()
    
    let panelWidth: CGFloat = 2.4
    let panelHeight: CGFloat = 0.0015
    let panelLength: CGFloat = 0.9
    
    let box = SCNBox(width: panelWidth, height: panelHeight, length: panelLength, chamferRadius: 0)
    box.materials = materials
    let boxNode = SCNNode(geometry: box)
    boxNode.position = SCNVector3(1.45, 0.025, 0)
    
    let gridNode = SCNNode()
    
    let numColumns = 6
    let numRows = 3
    
    let verticalLineThickness: CGFloat = 0.005     
    let horizontalLineThickness: CGFloat = 0.005   
    let gridLineThickness: CGFloat = 0.0005        
    let gridColor = UIColor.darkGray
    
    for i in 0...numColumns {
        let xPosition = -panelWidth / 2 + (panelWidth / CGFloat(numColumns)) * CGFloat(i)
        let lineBox = SCNBox(width: verticalLineThickness, height: gridLineThickness, length: panelLength, chamferRadius: 0)
        let lineMaterial = SCNMaterial()
        lineMaterial.diffuse.contents = gridColor
        lineBox.materials = [lineMaterial]
        let lineNode = SCNNode(geometry: lineBox)
        lineNode.position = SCNVector3(xPosition, panelHeight / 2 + gridLineThickness / 2, 0)
        gridNode.addChildNode(lineNode)
    }
    
    for j in 0...numRows {
        let zPosition = -panelLength / 2 + (panelLength / CGFloat(numRows)) * CGFloat(j)
        let lineBox = SCNBox(width: panelWidth, height: gridLineThickness, length: horizontalLineThickness, chamferRadius: 0)
        let lineMaterial = SCNMaterial()
        lineMaterial.diffuse.contents = gridColor
        lineBox.materials = [lineMaterial]
        let lineNode = SCNNode(geometry: lineBox)
        lineNode.position = SCNVector3(0, panelHeight / 2 + gridLineThickness / 2, zPosition)
        gridNode.addChildNode(lineNode)
    }
    
    boxNode.addChildNode(gridNode)
    parentNode.addChildNode(boxNode)
    
    return parentNode
}

func getJoint(position: SCNVector3, inAR: Bool) -> SCNNode {
    let parentNode = SCNNode()
    
    let jointMaterial = SCNMaterial()
    jointMaterial.diffuse.contents = UIColor.black
    //    jointMaterial.roughness.contents = 0.9
    //    jointMaterial.reflective.contents = 0.3
    jointMaterial.metalness.contents = 0.5
    if !inAR {
        jointMaterial.lightingModel = .physicallyBased
    }
    
    let cylinder = SCNCylinder(radius: 0.035, height: 0.2)
    cylinder.materials = [jointMaterial]
    let cylinderNode = SCNNode(geometry: cylinder)
    cylinderNode.eulerAngles = SCNVector3(0,0, Float.pi/2)
    cylinderNode.position = position
    
    parentNode.addChildNode(cylinderNode)
    
     return parentNode   
}
