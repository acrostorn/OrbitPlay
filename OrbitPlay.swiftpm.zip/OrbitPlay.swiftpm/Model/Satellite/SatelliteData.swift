//
//  SatelliteComponents.swift
//  LearnEarthOrbit
//
//  Created by USER on 2024/12/12.
//
//import Foundation
import SwiftUI
import SceneKit

struct SatelliteComponent: Codable, Transferable, Identifiable, Hashable, Equatable {
    var id: UUID = UUID()
    
    let type: ComponentType
    let name: String
    let cost: Float
    let weight: Float
    let description: String
    
    static var transferRepresentation: some TransferRepresentation {
        CodableRepresentation(for: SatelliteComponent.self, contentType: .data)
    }
}

class UserComponents: ObservableObject {
    @Published var bodyMaterial: SatelliteComponent
    @Published var solarPanel: SatelliteComponent
    @Published var selectedComponent: SatelliteComponent
    
    @Published var camera: SatelliteComponent?
    @Published var sensor: SatelliteComponent?
    @Published var coolingSystem: SatelliteComponent?
    @Published var antenna: SatelliteComponent?
    
    init() {
        self.bodyMaterial = SatelliteComponent(type: .bodyMaterial, name: "Wire Blanket", cost: 0, weight: 0, description: "test")
        self.solarPanel  = SatelliteComponent(type: .solarPanel, name: "Wire Panel", cost: 0, weight: 0, description: "test")
        self.selectedComponent = self.allComponents[0]
    }
    
    var values: [SatelliteComponent] {
        return [
            bodyMaterial,
            solarPanel
        ]
    }
    
    let allComponents: [SatelliteComponent] = [
        SatelliteComponent(type: .bodyMaterial, name: "Polyimide Shield Body", cost: 1, weight: 0.2, description: "This satellite's body is wrapped in a gold-colored polyimide thermal blanket that blocks external heat. Its color comes from a silver or aluminum-coated backside.\n\n(Source: JAXA FAQ, fanfun.jaxa.jp/faq)"),
        SatelliteComponent(type: .bodyMaterial, name: "Silver Radiative Body", cost: 1, weight: 0.09, description: "This satellite's silver radiative body regulates temperature with Optical Solar Reflectors (OSRs), which reflect sunlight and emit infrared radiation for extreme thermal conditions.\n\n(Source: JAXA ISAS, isas.jaxa.jp/feature/mio)"),
        SatelliteComponent(type: .bodyMaterial, name: "Black Insulated Body", cost: 1, weight: 0.15, description: "The Black Insulated Body uses carbon-infused insulation to prevent charge buildup, addressing gold insulation’s conductivity issues and ensuring durability in extreme space conditions.\n\n(Source: Oukado.org, oukado.org/kaihatsu)"),
        SatelliteComponent(type: .bodyMaterial, name: "White Beta Cloth Body", cost: 1, weight: 0.3, description: "The White Beta Cloth Body uses glass fiber Beta Cloth with aluminum coating, resisting atomic oxygen and extreme temperatures for durability in low Earth orbit.\n \n(Source: Fabriclore, fabriclore.com/blogs/fabric-wiki)"),
        SatelliteComponent(type: .solarPanel, name: "Triple-Junction Solar Panel", cost: 7, weight: 32, description: "This solar panel uses InGaP, GaAs, and Ge layers to absorb a broad solar spectrum with high efficiency. Radiation-resistant, it suits long missions and high-power satellites.\n\n(Source: JAXA, (kenkai.jaxa.jp/research) "),
        SatelliteComponent(type: .solarPanel, name: "Thin-Film Flexible Solar Panel", cost: 6, weight: 28, description: "This lightweight, flexible solar panel uses a thin-film structure, adapting to curved surfaces and foldable designs. Ideal for CubeSats and deployable arrays in experimental missions.\n\n(Source: NEDO, nedo.go.jp)"),
        SatelliteComponent(type: .solarPanel, name: "High-Temperature Resistant Solar Panel", cost: 5, weight: 18, description: "This solar panel, built for extreme heat, uses reflective coatings and heat-resistant materials to stay efficient near the Sun. Ideal for missions to Mercury, Venus, and high-temperature environments.\n\n(Source: Source: ESA, esa.int)"),
        SatelliteComponent(type: .solarPanel, name: "RTG-Assisted Solar Panel", cost: 5, weight: 8, description: "This solar panel features an auxiliary RTG for power in low-sunlight environments, making it ideal for deep-space missions to Jupiter, Saturn, and beyond.\n\n(Source: NASA, solarsystem.nasa.gov)")
    ]
}

enum ComponentType: Codable {
    case bodyMaterial
    case solarPanel
    case camera
    case sensor
    case coolingSystem
    case antenna
}

struct ComponentPreview: UIViewRepresentable {
    let component: SatelliteComponent
    var cameraPosition: SCNVector3
    var modelPivotPosition: SCNVector3
    var color: UIColor
    
    init(component: SatelliteComponent, color: UIColor) {
        self.component = component
        self.cameraPosition = SCNVector3(1.3, 1.3, 1.3)
        self.modelPivotPosition = SCNVector3(0, 0, 0)
        self.color = color
        
        if component.type == .solarPanel {
            self.cameraPosition.x += 1.95
            self.modelPivotPosition.x += 1.95
        }
    }
    
    func makeUIView(context: Context) -> SCNView {
        let scnView = SCNView()
        scnView.scene = createScene()
        scnView.backgroundColor = color
        scnView.autoenablesDefaultLighting = true
        return scnView
    }
    
    func updateUIView(_ scnView: SCNView, context: Context) {
        scnView.scene = createScene()
    }
    
    private func createScene() -> SCNScene {
        let scene = SCNScene()
        
        let modelNode = getModel(component)
        modelNode.position = SCNVector3(x: 0, y: 0, z: 0)
        scene.rootNode.addChildNode(modelNode)
        
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = cameraPosition
        cameraNode.look(at: modelPivotPosition)
        scene.rootNode.addChildNode(cameraNode)
        
        return scene
    }
}

func getModel(_ component: SatelliteComponent, inAR: Bool = false) -> SCNNode {
    let parentNode = SCNNode()
    
    switch component.type {
    case .bodyMaterial:
        let body = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
        body.materials = getMaterials(component, inAR: inAR)
        let bodyNode = SCNNode(geometry: body)
        let boardMaterial = SCNMaterial()
        if component.name == "Silver Radiative Body" {
            boardMaterial.diffuse.contents = UIColor.black
        } else {
            boardMaterial.diffuse.contents = UIColor.lightGray
        }
        boardMaterial.roughness.contents = 0.3
        boardMaterial.roughness.intensity = 0.2
        if !inAR {
            boardMaterial.reflective.contents = 1
            boardMaterial.metalness.contents = 1
            boardMaterial.lightingModel = .physicallyBased
        }
        boardMaterial.roughness.intensity = 0
        if component.name != "Wire Blanket" {
            parentNode.addChildNode(assembleBoards(mainMaterial: body.materials.first!, subMaterial: boardMaterial, inAR: inAR))
        }
        parentNode.addChildNode(bodyNode)
        
    case .solarPanel:
        switch component.name {
        case "Triple-Junction Solar Panel":
            let materials = getMaterials(component, inAR: inAR)
            
            parentNode.addChildNode(assemblePanels(inAR: inAR, style: "A", materials: materials))
        case "Thin-Film Flexible Solar Panel":
            let materials = getMaterials(component, inAR: inAR)
            
            parentNode.addChildNode(assemblePanels(inAR: inAR, style: "B", materials: materials))
        case "High-Temperature Resistant Solar Panel":
            let materials = getMaterials(component, inAR: inAR)
            
            parentNode.addChildNode(assemblePanels(inAR: inAR, style: "A", materials: materials))
        case "RTG-Assisted Solar Panel":
            let materials = getMaterials(component, inAR: inAR)
            
            parentNode.addChildNode(assemblePanels(inAR: inAR, style: "B", materials: materials))
        default :
            let mainBody = SCNBox(width: 2.5, height: 0.1, length: 1.0, chamferRadius: 0)
            mainBody.materials = getMaterials(component, inAR: inAR)
            let mainBodyNode = SCNNode(geometry: mainBody)
            mainBodyNode.position = SCNVector3(1.45, 0, 0)
            
            parentNode.addChildNode(mainBodyNode)
        }
    default :
        let body = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
        let bodyNode = SCNNode(geometry: body)
        parentNode.addChildNode(bodyNode)
    }
    
    return parentNode
}

func getMaterials(_ component: SatelliteComponent, inAR: Bool) -> [SCNMaterial] {
    var materials = [SCNMaterial()]
    
    switch component.name {
    case "Polyimide Shield Body" :
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.yellow
        material.roughness.contents = 0.3
        material.roughness.intensity = 0.2
        if !inAR {
            material.reflective.contents = 1
            material.metalness.contents = 1
            material.lightingModel = .physicallyBased
        }
        materials = [material]
    case "Silver Radiative Body" :
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.lightGray
        material.roughness.contents = 0.3
        material.roughness.intensity = 0.2
        if !inAR {
            material.reflective.contents = 1
            material.metalness.contents = 1
            material.lightingModel = .physicallyBased
        }
        materials = [material]
    case "Black Insulated Body" :
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.black
        material.roughness.contents = 0.3
        material.roughness.intensity = 0.2
        if !inAR {
            material.metalness.contents = 1
            material.reflective.contents = 1
            material.lightingModel = .physicallyBased
        }
        materials = [material]
    case "White Beta Cloth Body" :
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.white
        if !inAR {
            material.lightingModel = .physicallyBased
        }
        material.roughness.intensity = 0
        materials = [material]
    case "Triple-Junction Solar Panel":
        let material = SCNMaterial()
        material.diffuse.contents = UIColor(red: 26/255, green: 0, blue: 26/255, alpha: 1.0)
        material.metalness.contents = 1.0
        material.roughness.contents = 0.2
        if !inAR {
            material.lightingModel = .physicallyBased
        }
        material.roughness.intensity = 0
        materials = [material]
    case "Thin-Film Flexible Solar Panel":
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.black
        material.metalness.contents = 1.0
        material.roughness.contents = 0.2
        if !inAR {
            material.lightingModel = .physicallyBased
        }
        material.roughness.intensity = 0
        materials = [material]
    case "High-Temperature Resistant Solar Panel":
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.blue
        material.metalness.contents = 1.0
        material.roughness.contents = 0.2
        if !inAR {
            material.lightingModel = .physicallyBased
        }
        material.roughness.intensity = 0
        materials = [material]
    case "RTG-Assisted Solar Panel":
        let material = SCNMaterial()
        material.diffuse.contents = UIColor(red: 10/255, green: 10/255, blue: 50/255, alpha: 1.0)
        material.metalness.contents = 1.0
        material.roughness.contents = 0.2
        if !inAR {
            material.lightingModel = .physicallyBased
        }
        material.roughness.intensity = 0
        materials = [material]
    default :
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.gray
        material.transparency = 0.5
        material.transparencyMode = .aOne
        material.fillMode = .lines
        materials = [material]
    }
    
    return materials
}




